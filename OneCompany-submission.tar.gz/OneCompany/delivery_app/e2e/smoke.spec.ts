import { test, expect } from "@playwright/test";

test("app shell loads with product UI (not scaffold placeholder)", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByTestId("app-shell")).toBeVisible();
  await expect(page.getByTestId("app-title")).toBeVisible();
  await expect(page.getByTestId("app-title")).not.toHaveText("generated-app");
  await expect(page.getByTestId("app-page")).toBeVisible();
});
