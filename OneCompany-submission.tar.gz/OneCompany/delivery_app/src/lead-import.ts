export interface Lead {
  company: string;
  contactName: string;
  phone: string;
  email: string;
  intentionLevel: "高" | "中" | "低";
}

export interface ImportResult {
  total: number;
  imported: number;
  skipped: number;
  overwritten: number;
  summary: string;
}

export function validateLead(lead: Lead): { valid: boolean; error?: string } {
  if (!lead.company.trim()) return { valid: false, error: "公司名不能为空" };
  if (!lead.contactName.trim()) return { valid: false, error: "联系人不能为空" };
  return { valid: true };
}

export function parseCsvToLeads(csv: string): Lead[] {
  const lines = csv.trim().split("\n");
  if (lines.length <= 1) return [];

  const leads: Lead[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",").map((c) => c.trim());
    if (cols.length < 5) continue;
    const [company, contactName, phone, email, intentionLevel] = cols;
    if (!company || !contactName) continue;
    const validLevels = ["高", "中", "低"];
    const level = validLevels.includes(intentionLevel)
      ? (intentionLevel as "高" | "中" | "低")
      : "低";
    leads.push({ company, contactName, phone, email, intentionLevel: level });
  }
  return leads;
}

export function detectDuplicates(
  newLeads: Lead[],
  existingLeads: Lead[]
): { duplicates: Array<{ lead: Lead; action: "skip" | "overwrite" }>; unique: Lead[] } {
  const duplicates: Array<{ lead: Lead; action: "skip" | "overwrite" }> = [];
  const unique: Lead[] = [];

  for (const lead of newLeads) {
    const isDup = existingLeads.some(
      (e) => e.company === lead.company && e.contactName === lead.contactName
    );
    if (isDup) {
      duplicates.push({ lead, action: "skip" });
    } else {
      unique.push(lead);
    }
  }
  return { duplicates, unique };
}

export function generateTemplateBuffer(): Uint8Array {
  const xlsxBase64 =
    "UEsDBBQABgAIAAAAIQDfpP1BxwEAAMoBAAATAAgCW0NvbnRlbnRfVHlwZXNdLnhtbCCiBAIooAAC" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAC0lM1uwzAMhN8F7Ae4fUmW40euQIET9FD02EMQxGpjN5JsKXRIrz5OWhQF2qI9GKJ+" +
    "LOfhDIf0lVNR4kJ453TMUkJzhXlZ4JxOp8Ocw+f3fOJwzrNCKCE0JZIQIWRNCaUVzqlFN8c5" +
    "h2/JKfvym7V/D8f9Ydsftmm3a4+vTdrvtqf9/vCymzfjZtpOm/FwPE6H/dtmPP3jKIu2rJE+" +
    "5VNIU5ZdlRfTpG0d66qqqC7LoqqDzsqszao2K+qsCUGVsqpzWoRZkIWg8rIIKsh9nYtQBDXL" +
    "q5pmFZdBXWdFFeYh9WVZhbKu6pCKqihDVftC5FVVVVleB1WUecjLsqxF2eS5COu6qIqqrUXe" +
    "FN6HoA4hFFUVZCnyvKzLuq7KuqzzugxB5WXIi6rO87Zuq7wJQVVVWVVVXYWqqkJVVnkV8qKo" +
    "Q1GXuS/Kss7rOizfZlR/yov+AAAA//9QSwMEFAAGAAgAAAAhAN8EJ3RtAgAAtAIAABoACAFf" +
    "cmVscy8ucmVscy54bWwgogQCKKAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAvJLLTsMwEEV/xH6D8jarJE1LK4FECxIPsLGXOInrEJnY" +
    "lr0JRVX/HSdtKSLBYsV9mfPlnJn06b2UMoUjdm2dpRO4IJjWNbU5vozu97v+8GHQ7Q0HcDCG" +
    "4aA3eOo97nb9QdcfDnvD/mA0Gn780yZLEWNV0oyqLCVxYwihKkmCJIVz8cXh/Wq5Kh+Kcr1a" +
    "l/fLh1LKh/JxuSiX5XxVzjaXZbn+2psuVoCp65oyOOjYtrGqV9QUVUiC5MX5m8P7w/6C8Gn3" +
    "OXxB2Db5NPkdpE32Pn5B2PY8n/9C+PI8B/8Q0ucDdIcAAAAAAP//UEsDBBQABgAIAAAAIQCZ" +
    "V6QixwEAAOoCAAALAAAAY2hsZFJlbGF0aW9ucy8ucmVscy54bWwgogQCKKAAAgAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHySzQ7CMAyG7ye9Q7B+" +
    "SdOyaQMh8QAX4MwPmJZYVep0MOLdiROwMDHx5P98sV+eCqVyPGHfdUW+gDPBuGnpIPB5tD++" +
    "2V82h+5heILJCEaTQX88GU+nw/64N5gMR4Ph5PPflKpSxrqSc1I2DblWQkjlPClCcBk1Gq2t" +
    "zihLSI0kW4VGlRlpqRTKWFJqrdOQ1n5XdpVWUn7tTxerSq/8VOll6D5yp3aqylZfZVlJVGXF" +
    "ejOvwGQ2mU+pRnJ1GP8eAAAA//9QSwMEFAAGAAgAAAAhAKR6xGR0AwAAhAMAABEAAAB3b3Jr" +
    "Ym9vay54bWysk81OwzAQhO8S8Q7ivs0mTVOJFkqcOEBV4AvY2G0ke228NqGq7x5nW1QUAfEA" +
    "F1br+fn2x/PLG8VCOx6Ltu4KegZrgrjpyEng097+uG5/G4edfr8/gIMR9Hvd7lOv87jrdQfd" +
    "0aA76vdHo+HnP01UCmnSklSUJQkba91YrK0xGqVR58Nh9X5VZvNyvi7ny82yzF+Xy9Xi4WFZ" +
    "luXysiyvm6u63Hztj+dLwNB2TVOddELXNM6bIC25lNRTGOGcQlhlmFBYVqwSKiNxztY5iykr" +
    "4bKUlJCiNuSyCAtRFEXIiiYoP82cCpqirJuwqHwtylAVfpH7oqiDLOoiL6rWL0QI1tYYUXdR" +
    "ZVVVdV3VVWizbPIQVFZlmddlXWV1ldVVUOcqy+qiqKu8qqrML0QI46quy6rK87rK87oKVVVV" +
    "dVXVZVlXVVkXVV2WIf82o/Inn/ECAAD//1BLAwQUAAYACAAAACEAU2XQU1sDAADsBAAADQAA" +
    "AF9yZWxzL3dvcmtib29rLnhtbC5yZWxz7FhtS8QwEP4r5ndI3ru22dl5Ij4IKir64kvc3GZl" +
    "adIu6Q7xvze7HT4oKILgwcvl+/LyPHlN1RUpVR66Yuq6qpjBAWFSNLQX+O1wOH53f7cbHu7v" +
    "wmQI09GgP570Z7N+3O8MZsPhYDD5+GenSUp1QVhSsW4SLEaTJokLYa0lxYeF+Djrl8vl4/J+" +
    "+VGV8Xa5rBbz+X2ZP5T3q3K1uazK8uuwN12sAEPT1pV10NFN7bz3WltKuSq4sJBONXWkIayN" +
    "lK1BnYW4aJBKVZWhNCi9lnmVZ0UIeV6GtAqLPCy9kr6q87wWZZaFsqjyUFRlKMOq9FUVVFmV" +
    "VVnURVUXXVFVRVgXdQiqrPK8KuqqKsNCFHmel1VR13leVXleB1XVVVVWRV3leVXleV2Fsq6r" +
    "qqrqqqirKs+rKs+rqizLWpRVXoe8KvO8ruqyLP82o/InP+MFAAD//1BLAwQUAAYACAAAACEA" +
    "AAAAAAAAAAAAAAAZAAAAdGhlbWUvdGhlbWUxLnhtbOxZzW8aRxT/lfY9xNkFGyywMYkl5GBi" +
    "g4kN5NCmpO1q1vJ4dmd2VrJ3/7OzCxhIb6kU9dJb/4D+Af0H0lMvufXSQw899dRL/wAAAAD" +
    "/kAQA";

  const binary = atob(xlsxBase64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export function addLeadManually(
  leads: Lead[],
  lead: Lead
): { success: boolean; error?: string } {
  const validation = validateLead(lead);
  if (!validation.valid) return { success: false, error: validation.error };

  const isDup = leads.some(
    (l) => l.company === lead.company && l.contactName === lead.contactName
  );
  if (isDup) return { success: false, error: "线索重复，已存在相同公司名和联系人" };

  leads.push({ ...lead });
  return { success: true };
}

export function batchImportLeads(
  existing: Lead[],
  newLeads: Lead[],
  options?: { duplicateAction?: "skip" | "overwrite" }
): ImportResult {
  const action = options?.duplicateAction ?? "skip";
  let imported = 0;
  let skipped = 0;
  let overwritten = 0;

  for (const lead of newLeads) {
    const dupIndex = existing.findIndex(
      (e) => e.company === lead.company && e.contactName === lead.contactName
    );
    if (dupIndex >= 0) {
      if (action === "overwrite") {
        existing[dupIndex] = { ...lead };
        imported++;
        overwritten++;
      } else {
        skipped++;
      }
    } else {
      existing.push({ ...lead });
      imported++;
    }
  }

  const summary = `共 ${newLeads.length} 条，导入 ${imported} 条，跳过 ${skipped} 条，覆盖 ${overwritten} 条`;
  return { total: newLeads.length, imported, skipped, overwritten, summary };
}
