import { type User } from "./auth.js";
import { type Customer, getCustomers } from "./customers.js";

export const mockUsers: User[] = [
  { username: "sales1", role: "sales", displayName: "张销售" },
  { username: "sales2", role: "sales", displayName: "李销售" },
  { username: "admin1", role: "admin", displayName: "管理员" },
  { username: "manager1", role: "manager", displayName: "王经理" },
];

export const mockCustomers: Customer[] = getCustomers();
