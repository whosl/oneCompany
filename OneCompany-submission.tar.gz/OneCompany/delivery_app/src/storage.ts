import type { Customer } from "./customers.js";
import { seedCustomers } from "./seed.js";

const STORAGE_KEY = "crm_customers";

/**
 * Load customers from a storage backend (localStorage in the browser, a mock
 * Storage in tests). On first run (no data) the seed dataset is persisted and
 * returned so the app always has data to show.
 */
export function loadCustomers(storage: Storage): Customer[] {
  const raw = storage.getItem(STORAGE_KEY);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed as Customer[];
    } catch {
      // fall through to seed
    }
  }
  // First run: persist the seed so subsequent reads are stable.
  saveCustomers(storage, seedCustomers);
  return seedCustomers.slice();
}

/** Persist customers to the storage backend. */
export function saveCustomers(storage: Storage, customers: Customer[]): void {
  storage.setItem(STORAGE_KEY, JSON.stringify(customers));
}

/** Reset to seed data (used by tests and a potential "reset" UI action). */
export function resetCustomers(storage: Storage): Customer[] {
  saveCustomers(storage, seedCustomers);
  return seedCustomers.slice();
}
