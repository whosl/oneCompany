export interface User {
  username: string;
  role: "sales" | "admin" | "manager";
  displayName: string;
}

export interface AuthResult {
  success: boolean;
  user?: User;
  error?: string;
  redirectTo?: string;
}

const users: User[] = [
  { username: "sales1", role: "sales", displayName: "张销售" },
  { username: "sales2", role: "sales", displayName: "李销售" },
  { username: "admin1", role: "admin", displayName: "管理员" },
  { username: "manager1", role: "manager", displayName: "王经理" },
];

const passwords: Record<string, string> = {
  sales1: "123456",
  sales2: "123456",
  admin1: "admin123",
  manager1: "123456",
};

let currentSession: User | null = null;

const roleRedirects: Record<string, string> = {
  sales: "/customers",
  admin: "/admin",
  manager: "/dashboard",
};

export function authenticate(username: string, password: string): AuthResult {
  const user = users.find((u) => u.username === username);
  if (!user || passwords[username] !== password) {
    return { success: false, error: "用户名或密码错误" };
  }
  currentSession = user;
  return {
    success: true,
    user,
    redirectTo: roleRedirects[user.role] || "/",
  };
}

export function getSession(): User | null {
  return currentSession;
}

export function logout(): void {
  currentSession = null;
}

export function canAccessCustomer(
  user: User,
  customer: { ownerUsername: string }
): boolean {
  if (user.role === "admin" || user.role === "manager") return true;
  return customer.ownerUsername === user.username;
}

export function canModifyCustomer(
  user: User,
  _customer: { ownerUsername: string }
): boolean {
  return user.role === "admin" || user.role === "manager";
}
