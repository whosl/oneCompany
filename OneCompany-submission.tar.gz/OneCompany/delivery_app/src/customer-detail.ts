export interface CustomerDetail {
  id: string;
  name: string;
  company: string;
  intentionLevel: "高" | "中" | "低";
  intentionScore: number;
  lastFollowUpAt: string;
  phone: string;
  email: string;
  scoreReason: string;
  owner: string;
  deleted: boolean;
}

export type FollowUpMethod = "电话" | "邮件" | "拜访" | "其他";

export interface FollowUp {
  id: string;
  customerId: string;
  content: string;
  method: FollowUpMethod;
  createdBy: string;
  createdAt: string;
}

let nextId = 1;

export function getCustomerById(
  customers: CustomerDetail[],
  id: string
): CustomerDetail | undefined {
  return customers.find((c) => c.id === id && !c.deleted);
}

export function getFollowUps(
  followUps: FollowUp[],
  customerId: string
): FollowUp[] {
  return followUps
    .filter((f) => f.customerId === customerId)
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
}

export function addFollowUp(
  followUps: FollowUp[],
  data: {
    customerId: string;
    content: string;
    method: FollowUpMethod;
    createdBy: string;
  }
): FollowUp {
  if (!data.content.trim()) {
    throw new Error("跟进内容不能为空");
  }
  const validMethods: FollowUpMethod[] = ["电话", "邮件", "拜访", "其他"];
  if (!validMethods.includes(data.method)) {
    throw new Error("无效的跟进方式");
  }
  const entry: FollowUp = {
    id: `f${nextId++}`,
    customerId: data.customerId,
    content: data.content,
    method: data.method,
    createdBy: data.createdBy,
    createdAt: new Date().toISOString(),
  };
  followUps.push(entry);
  return entry;
}

export function softDeleteCustomer(
  customers: CustomerDetail[],
  id: string
): boolean {
  const c = customers.find((c) => c.id === id && !c.deleted);
  if (!c) return false;
  c.deleted = true;
  return true;
}

export function reassignCustomer(
  customers: CustomerDetail[],
  followUps: FollowUp[],
  customerId: string,
  newOwner: string
): { success: boolean } {
  const c = customers.find((c) => c.id === customerId && !c.deleted);
  if (!c) return { success: false };
  if (c.owner === newOwner) return { success: false };
  const oldOwner = c.owner;
  c.owner = newOwner;
  addFollowUp(followUps, {
    customerId,
    content: `客户从 ${oldOwner} 转交给 ${newOwner}`,
    method: "其他",
    createdBy: oldOwner,
  });
  return { success: true };
}

export function regenerateAIScore(customerId: string): {
  level: "高" | "中" | "低";
  score: number;
  reason: string;
} {
  const hash = Array.from(customerId).reduce(
    (h, ch) => (h * 31 + ch.charCodeAt(0)) & 0xffffff,
    0
  );
  const score = 40 + (hash % 56);
  let level: "高" | "中" | "低";
  if (score >= 80) level = "高";
  else if (score >= 60) level = "中";
  else level = "低";
  const reasons = [
    "根据近期沟通频率和客户反馈综合评估",
    "基于客户行业趋势和历史合作数据分析",
    "结合客户活跃度和购买意向模型推算",
    "依据最近互动记录和需求匹配度评定",
  ];
  const reason = reasons[hash % reasons.length];
  return { level, score, reason };
}
