export interface Customer {
  id: string;
  name: string;
  company: string;
  intentionLevel: "高" | "中" | "低";
  intentionScore: number;
  lastFollowUpAt: string;
  phone: string;
  email: string;
  ownerUsername: string;
  createdAt: string;
}

export function getCustomers(): Customer[] {
  return mockCustomerData.slice();
}

export function filterCustomers(
  customers: Customer[],
  filters: { nameKeyword?: string; intentionLevel?: string }
): Customer[] {
  let result = customers;
  if (filters.nameKeyword) {
    const keyword = filters.nameKeyword;
    result = result.filter((c) => c.name.includes(keyword));
  }
  if (filters.intentionLevel) {
    result = result.filter(
      (c) => c.intentionLevel === filters.intentionLevel
    );
  }
  return result;
}

export function sortCustomers(
  customers: Customer[],
  field: "intentionScore" | "lastFollowUpAt",
  direction: "asc" | "desc"
): Customer[] {
  return [...customers].sort((a, b) => {
    let valA: number, valB: number;
    if (field === "intentionScore") {
      valA = a.intentionScore;
      valB = b.intentionScore;
    } else {
      valA = new Date(a.lastFollowUpAt).getTime();
      valB = new Date(b.lastFollowUpAt).getTime();
    }
    return direction === "asc" ? valA - valB : valB - valA;
  });
}

export interface PaginatedResult {
  items: Customer[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export function paginateCustomers(
  customers: Customer[],
  page: number,
  pageSize: number
): PaginatedResult {
  const start = (page - 1) * pageSize;
  return {
    items: customers.slice(start, start + pageSize),
    total: customers.length,
    page,
    pageSize,
    totalPages: Math.ceil(customers.length / pageSize),
  };
}

const mockCustomerData: Customer[] = [
  {
    id: "1",
    name: "张三",
    company: "阿里巴巴",
    intentionLevel: "高",
    intentionScore: 95,
    lastFollowUpAt: "2026-06-13T10:00:00Z",
    phone: "13800000001",
    email: "zhangsan@alibaba.com",
    ownerUsername: "sales1",
    createdAt: "2026-06-01T08:00:00Z",
  },
  {
    id: "2",
    name: "李四",
    company: "腾讯科技",
    intentionLevel: "高",
    intentionScore: 88,
    lastFollowUpAt: "2026-06-12T14:30:00Z",
    phone: "13800000002",
    email: "lisi@tencent.com",
    ownerUsername: "sales1",
    createdAt: "2026-06-02T09:00:00Z",
  },
  {
    id: "3",
    name: "王五",
    company: "字节跳动",
    intentionLevel: "中",
    intentionScore: 72,
    lastFollowUpAt: "2026-06-11T09:15:00Z",
    phone: "13800000003",
    email: "wangwu@bytedance.com",
    ownerUsername: "sales2",
    createdAt: "2026-06-03T10:00:00Z",
  },
  {
    id: "4",
    name: "赵六",
    company: "美团",
    intentionLevel: "低",
    intentionScore: 45,
    lastFollowUpAt: "2026-06-10T16:45:00Z",
    phone: "13800000004",
    email: "zhaoliu@meituan.com",
    ownerUsername: "sales2",
    createdAt: "2026-06-05T11:00:00Z",
  },
  {
    id: "5",
    name: "张伟",
    company: "京东集团",
    intentionLevel: "中",
    intentionScore: 68,
    lastFollowUpAt: "2026-06-09T11:20:00Z",
    phone: "13800000005",
    email: "zhangwei@jd.com",
    ownerUsername: "sales1",
    createdAt: "2026-05-20T08:00:00Z",
  },
  {
    id: "6",
    name: "孙七",
    company: "华为技术",
    intentionLevel: "高",
    intentionScore: 91,
    lastFollowUpAt: "2026-06-08T08:00:00Z",
    phone: "13800000006",
    email: "sunqi@huawei.com",
    ownerUsername: "sales2",
    createdAt: "2026-05-15T09:00:00Z",
  },
  {
    id: "7",
    name: "周八",
    company: "小米科技",
    intentionLevel: "低",
    intentionScore: 38,
    lastFollowUpAt: "2026-06-07T15:30:00Z",
    phone: "13800000007",
    email: "zhouba@xiaomi.com",
    ownerUsername: "sales1",
    createdAt: "2026-06-10T07:00:00Z",
  },
  {
    id: "8",
    name: "吴九",
    company: "百度在线",
    intentionLevel: "中",
    intentionScore: 75,
    lastFollowUpAt: "2026-06-06T13:10:00Z",
    phone: "13800000008",
    email: "wujiu@baidu.com",
    ownerUsername: "sales2",
    createdAt: "2026-05-25T14:00:00Z",
  },
  {
    id: "9",
    name: "郑十",
    company: "网易",
    intentionLevel: "高",
    intentionScore: 85,
    lastFollowUpAt: "2026-06-05T09:45:00Z",
    phone: "13800000009",
    email: "zhengshi@netease.com",
    ownerUsername: "sales1",
    createdAt: "2026-06-08T16:00:00Z",
  },
  {
    id: "10",
    name: "张明",
    company: "拼多多",
    intentionLevel: "低",
    intentionScore: 42,
    lastFollowUpAt: "2026-06-04T17:00:00Z",
    phone: "13800000010",
    email: "zhangming@pdd.com",
    ownerUsername: "sales2",
    createdAt: "2026-06-12T11:00:00Z",
  },
];
