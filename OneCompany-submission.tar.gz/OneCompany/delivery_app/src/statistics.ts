export interface CustomerRecord {
  id: string;
  name: string;
  company: string;
  intentionLevel: "高" | "中" | "低";
  intentionScore: number;
  lastFollowUpAt: string;
  phone: string;
  email: string;
  ownerUsername: string;
  createdAt: string;
}

export interface TeamOverview {
  totalLeadCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  conversionRate: number;
  newThisMonth: number;
}

export interface IntentionDistribution {
  level: "高" | "中" | "低";
  count: number;
}

export interface MemberRank {
  username: string;
  displayName: string;
  count: number;
}

export interface TrendPoint {
  date: string;
  count: number;
}

export function computeTeamOverview(
  customers: CustomerRecord[],
  referenceDate?: string
): TeamOverview {
  const totalLeadCount = customers.length;
  const highCount = customers.filter((c) => c.intentionLevel === "高").length;
  const mediumCount = customers.filter((c) => c.intentionLevel === "中").length;
  const lowCount = customers.filter((c) => c.intentionLevel === "低").length;
  const conversionRate = totalLeadCount > 0 ? highCount / totalLeadCount : 0;

  const ref = referenceDate ? new Date(referenceDate) : new Date();
  const monthStr = `${ref.getFullYear()}-${String(ref.getMonth() + 1).padStart(2, "0")}`;
  const newThisMonth = customers.filter((c) => c.createdAt.startsWith(monthStr)).length;

  return { totalLeadCount, highCount, mediumCount, lowCount, conversionRate, newThisMonth };
}

export function computeIntentionDistribution(
  customers: CustomerRecord[]
): IntentionDistribution[] {
  const counts: Record<string, number> = { "高": 0, "中": 0, "低": 0 };
  for (const c of customers) {
    counts[c.intentionLevel]++;
  }
  return [
    { level: "高", count: counts["高"] },
    { level: "中", count: counts["中"] },
    { level: "低", count: counts["低"] },
  ];
}

export function computeMemberRanking(
  customers: CustomerRecord[],
  members: Array<{ username: string; displayName: string }>
): MemberRank[] {
  const countMap: Record<string, number> = {};
  for (const c of customers) {
    countMap[c.ownerUsername] = (countMap[c.ownerUsername] || 0) + 1;
  }
  return members
    .map((m) => ({
      username: m.username,
      displayName: m.displayName,
      count: countMap[m.username] || 0,
    }))
    .sort((a, b) => b.count - a.count);
}

function formatDateStr(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function computeTrendData(
  customers: CustomerRecord[],
  startDate: string,
  endDate: string
): TrendPoint[] {
  const dayCounts: Record<string, number> = {};
  const start = new Date(startDate);
  const end = new Date(endDate);

  const d = new Date(start);
  while (d <= end) {
    dayCounts[formatDateStr(d)] = 0;
    d.setDate(d.getDate() + 1);
  }

  for (const c of customers) {
    const day = c.createdAt.slice(0, 10);
    if (day in dayCounts) {
      dayCounts[day]++;
    }
  }

  return Object.entries(dayCounts).map(([date, count]) => ({ date, count }));
}

export function filterByTimeRange(
  customers: CustomerRecord[],
  startDate?: string,
  endDate?: string
): CustomerRecord[] {
  if (!startDate || !endDate) return customers;
  const end = new Date(endDate);
  end.setDate(end.getDate() + 1);
  const endExclusive = end.toISOString();
  return customers.filter(
    (c) => c.createdAt >= startDate && c.createdAt < endExclusive
  );
}
