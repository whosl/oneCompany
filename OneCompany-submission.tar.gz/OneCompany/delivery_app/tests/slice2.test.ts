import { describe, it, expect, beforeEach } from "vitest";
import {
  getCustomerById,
  getFollowUps,
  addFollowUp,
  softDeleteCustomer,
  reassignCustomer,
  regenerateAIScore,
  type CustomerDetail,
  type FollowUp,
} from "../src/customer-detail.js";
import { authenticate, logout } from "../src/auth.js";

const testCustomers: CustomerDetail[] = [
  {
    id: "1",
    name: "张三",
    company: "阿里巴巴",
    intentionLevel: "高",
    intentionScore: 85,
    lastFollowUpAt: "2026-06-13T10:00:00Z",
    phone: "13800000001",
    email: "zhangsan@alibaba.com",
    scoreReason: "客户沟通频繁，表达明确采购意向",
    owner: "sales1",
    deleted: false,
  },
  {
    id: "2",
    name: "李四",
    company: "腾讯科技",
    intentionLevel: "高",
    intentionScore: 88,
    lastFollowUpAt: "2026-06-12T14:30:00Z",
    phone: "13800000002",
    email: "lisi@tencent.com",
    scoreReason: "近期有明确需求",
    owner: "sales2",
    deleted: false,
  },
  {
    id: "3",
    name: "王五",
    company: "字节跳动",
    intentionLevel: "中",
    intentionScore: 72,
    lastFollowUpAt: "2026-06-11T09:15:00Z",
    phone: "13800000003",
    email: "wangwu@bytedance.com",
    scoreReason: "有一定兴趣但未明确表态",
    owner: "sales1",
    deleted: false,
  },
];

const testFollowUps: FollowUp[] = [
  {
    id: "f1",
    customerId: "1",
    content: "初次电话沟通，了解需求",
    method: "电话",
    createdBy: "sales1",
    createdAt: "2026-06-10T10:00:00Z",
  },
  {
    id: "f2",
    customerId: "1",
    content: "发送产品资料",
    method: "邮件",
    createdBy: "sales1",
    createdAt: "2026-06-12T14:00:00Z",
  },
];

describe("getCustomerById", () => {
  it("returns customer by id", () => {
    const c = getCustomerById(testCustomers, "1");
    expect(c).toBeDefined();
    expect(c!.name).toBe("张三");
    expect(c!.intentionLevel).toBe("高");
    expect(c!.intentionScore).toBe(85);
    expect(c!.scoreReason).toBe("客户沟通频繁，表达明确采购意向");
  });

  it("returns undefined for non-existent id", () => {
    const c = getCustomerById(testCustomers, "999");
    expect(c).toBeUndefined();
  });

  it("returns undefined for deleted customer", () => {
    const deleted: CustomerDetail[] = [
      { ...testCustomers[0], deleted: true },
    ];
    const c = getCustomerById(deleted, "1");
    expect(c).toBeUndefined();
  });
});

describe("getFollowUps", () => {
  it("returns follow-ups sorted by createdAt descending", () => {
    const result = getFollowUps(testFollowUps, "1");
    expect(result.length).toBe(2);
    expect(result[0].id).toBe("f2");
    expect(result[1].id).toBe("f1");
  });

  it("returns empty array for customer with no follow-ups", () => {
    const result = getFollowUps(testFollowUps, "999");
    expect(result).toEqual([]);
  });
});

describe("addFollowUp", () => {
  it("adds a new follow-up and returns it", () => {
    const followUps: FollowUp[] = [];
    const result = addFollowUp(followUps, {
      customerId: "1",
      content: "拜访客户",
      method: "拜访",
      createdBy: "sales1",
    });
    expect(result.id).toBeDefined();
    expect(result.customerId).toBe("1");
    expect(result.content).toBe("拜访客户");
    expect(result.method).toBe("拜访");
    expect(result.createdBy).toBe("sales1");
    expect(result.createdAt).toBeDefined();
    expect(followUps.length).toBe(1);
  });

  it("validates method type", () => {
    const followUps: FollowUp[] = [];
    expect(() =>
      addFollowUp(followUps, {
        customerId: "1",
        content: "test",
        method: "无效方式" as any,
        createdBy: "sales1",
      })
    ).toThrow("无效的跟进方式");
  });

  it("validates required fields", () => {
    const followUps: FollowUp[] = [];
    expect(() =>
      addFollowUp(followUps, {
        customerId: "1",
        content: "",
        method: "电话",
        createdBy: "sales1",
      })
    ).toThrow("跟进内容不能为空");
  });

  it("assigns unique ids to each follow-up", () => {
    const followUps: FollowUp[] = [];
    const r1 = addFollowUp(followUps, {
      customerId: "1",
      content: "a",
      method: "电话",
      createdBy: "sales1",
    });
    const r2 = addFollowUp(followUps, {
      customerId: "1",
      content: "b",
      method: "邮件",
      createdBy: "sales1",
    });
    expect(r1.id).not.toBe(r2.id);
  });
});

describe("softDeleteCustomer", () => {
  it("marks customer as deleted", () => {
    const customers: CustomerDetail[] = testCustomers.map((c) => ({
      ...c,
    }));
    const result = softDeleteCustomer(customers, "1");
    expect(result).toBe(true);
    expect(customers.find((c) => c.id === "1")!.deleted).toBe(true);
  });

  it("returns false for non-existent customer", () => {
    const customers: CustomerDetail[] = [...testCustomers];
    const result = softDeleteCustomer(customers, "999");
    expect(result).toBe(false);
  });

  it("returns false for already deleted customer", () => {
    const customers: CustomerDetail[] = [
      { ...testCustomers[0], deleted: true },
    ];
    const result = softDeleteCustomer(customers, "1");
    expect(result).toBe(false);
  });
});

describe("reassignCustomer", () => {
  it("reassigns customer to new owner", () => {
    const customers: CustomerDetail[] = testCustomers.map((c) => ({
      ...c,
    }));
    const followUps: FollowUp[] = [];
    const result = reassignCustomer(customers, followUps, "1", "sales2");
    expect(result.success).toBe(true);
    expect(customers.find((c) => c.id === "1")!.owner).toBe("sales2");
  });

  it("creates a follow-up record for reassignment", () => {
    const customers: CustomerDetail[] = testCustomers.map((c) => ({
      ...c,
    }));
    const followUps: FollowUp[] = [];
    reassignCustomer(customers, followUps, "1", "sales2");
    expect(followUps.length).toBe(1);
    expect(followUps[0].content).toContain("转交");
    expect(followUps[0].method).toBe("其他");
  });

  it("returns false for non-existent customer", () => {
    const customers: CustomerDetail[] = [...testCustomers];
    const followUps: FollowUp[] = [];
    const result = reassignCustomer(customers, followUps, "999", "sales2");
    expect(result.success).toBe(false);
  });

  it("returns false for deleted customer", () => {
    const customers: CustomerDetail[] = [
      { ...testCustomers[0], deleted: true },
    ];
    const followUps: FollowUp[] = [];
    const result = reassignCustomer(customers, followUps, "1", "sales2");
    expect(result.success).toBe(false);
  });

  it("does not reassign to same owner", () => {
    const customers: CustomerDetail[] = testCustomers.map((c) => ({
      ...c,
    }));
    const followUps: FollowUp[] = [];
    const result = reassignCustomer(customers, followUps, "1", "sales1");
    expect(result.success).toBe(false);
  });
});

describe("regenerateAIScore", () => {
  it("returns a new score with level, score, and reason", () => {
    const result = regenerateAIScore("1");
    expect(result.level).toBeDefined();
    expect(["高", "中", "低"]).toContain(result.level);
    expect(result.score).toBeGreaterThanOrEqual(0);
    expect(result.score).toBeLessThanOrEqual(100);
    expect(result.reason.length).toBeGreaterThan(0);
  });

  it("generates deterministic score for same customer id", () => {
    const r1 = regenerateAIScore("1");
    const r2 = regenerateAIScore("1");
    expect(r1.score).toBe(r2.score);
    expect(r1.level).toBe(r2.level);
  });

  it("generates different scores for different customer ids", () => {
    const r1 = regenerateAIScore("1");
    const r2 = regenerateAIScore("2");
    expect(r1.score).not.toBe(r2.score);
  });

  it("applies generated score to customer", () => {
    const customers: CustomerDetail[] = testCustomers.map((c) => ({
      ...c,
    }));
    const result = regenerateAIScore("1");
    const customer = customers.find((c) => c.id === "1")!;
    customer.intentionLevel = result.level;
    customer.intentionScore = result.score;
    customer.scoreReason = result.reason;
    expect(customer.intentionLevel).toBe(result.level);
    expect(customer.intentionScore).toBe(result.score);
    expect(customer.scoreReason).toBe(result.reason);
  });
});
