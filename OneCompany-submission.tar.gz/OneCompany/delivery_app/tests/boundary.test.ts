import { describe, it, expect } from "vitest";
import {
  getCustomers,
  filterCustomers,
  paginateCustomers,
  sortCustomers,
  type Customer,
} from "../src/customers.js";
import {
  getCustomerById,
  type CustomerDetail,
} from "../src/customer-detail.js";
import {
  validateLead,
  parseCsvToLeads,
  detectDuplicates,
  addLeadManually,
  batchImportLeads,
  type Lead,
} from "../src/lead-import.js";
import {
  canAccessCustomer,
  canModifyCustomer,
  type User,
} from "../src/auth.js";

describe("Boundary — empty list", () => {
  it("filterCustomers returns empty array for empty input", () => {
    expect(filterCustomers([], { nameKeyword: "张" })).toEqual([]);
  });

  it("filterCustomers returns empty array for empty filters on empty input", () => {
    expect(filterCustomers([], {})).toEqual([]);
  });

  it("paginateCustomers on empty list returns page 1 / 0 totalPages", () => {
    const page = paginateCustomers([], 1, 5);
    expect(page.items).toEqual([]);
    expect(page.total).toBe(0);
    expect(page.totalPages).toBe(0);
  });

  it("sortCustomers on empty list returns empty array", () => {
    expect(sortCustomers([], "intentionScore", "desc")).toEqual([]);
  });
});

describe("Boundary — invalid intention level", () => {
  it("filterCustomers with non-existent level returns empty", () => {
    const customers = getCustomers();
    // Cast to bypass type-check: simulates user injecting an invalid value.
    const result = filterCustomers(customers, { intentionLevel: "超高" as unknown as string });
    expect(result).toEqual([]);
  });
});

describe("Boundary — duplicate import rejection", () => {
  it("detects duplicate by company + contactName", () => {
    const existingLeads = [
      { company: "阿里巴巴", contactName: "张三", phone: "", email: "", intentionLevel: "高" },
    ];
    const isDup = existingLeads.some(
      (l) => l.company === "阿里巴巴" && l.contactName === "张三",
    );
    expect(isDup).toBe(true);
  });

  it("does not flag as duplicate when company differs", () => {
    const existingLeads = [
      { company: "阿里巴巴", contactName: "张三", phone: "", email: "", intentionLevel: "高" },
    ];
    const isDup = existingLeads.some(
      (l) => l.company === "腾讯科技" && l.contactName === "张三",
    );
    expect(isDup).toBe(false);
  });

  it("addLeadManually rejects duplicate company+contactName", () => {
    const leads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "", email: "", intentionLevel: "高" },
    ];
    const result = addLeadManually(leads, {
      company: "阿里巴巴",
      contactName: "张三",
      phone: "13800000001",
      email: "z@alibaba.com",
      intentionLevel: "高",
    });
    expect(result.success).toBe(false);
    expect(result.error).toContain("重复");
  });

  it("detectDuplicates correctly separates unique from duplicate", () => {
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "", email: "", intentionLevel: "高" },
      { company: "新公司", contactName: "新人", phone: "", email: "", intentionLevel: "中" },
    ];
    const existing: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "", email: "", intentionLevel: "高" },
    ];
    const result = detectDuplicates(newLeads, existing);
    expect(result.duplicates.length).toBe(1);
    expect(result.unique.length).toBe(1);
    expect(result.unique[0].company).toBe("新公司");
  });

  it("batchImportLeads skips duplicates by default", () => {
    const existing: Lead[] = [
      { company: "A", contactName: "X", phone: "", email: "", intentionLevel: "高" },
    ];
    const newLeads: Lead[] = [
      { company: "A", contactName: "X", phone: "", email: "", intentionLevel: "高" },
      { company: "B", contactName: "Y", phone: "", email: "", intentionLevel: "中" },
    ];
    const result = batchImportLeads(existing, newLeads);
    expect(result.imported).toBe(1);
    expect(result.skipped).toBe(1);
  });

  it("batchImportLeads overwrites when action is overwrite", () => {
    const existing: Lead[] = [
      { company: "A", contactName: "X", phone: "111", email: "a@x.com", intentionLevel: "低" },
    ];
    const newLeads: Lead[] = [
      { company: "A", contactName: "X", phone: "999", email: "new@x.com", intentionLevel: "高" },
    ];
    const result = batchImportLeads(existing, newLeads, { duplicateAction: "overwrite" });
    expect(result.imported).toBe(1);
    expect(result.overwritten).toBe(1);
    expect(existing[0].phone).toBe("999");
  });
});

describe("Boundary — non-existent customer id", () => {
  it("find returns undefined for non-existent id", () => {
    const customers = getCustomers();
    const found = customers.find((c) => c.id === "non-existent-id-999");
    expect(found).toBeUndefined();
  });

  it("getCustomerById returns undefined for non-existent id", () => {
    const customers: CustomerDetail[] = [
      { id: "1", name: "测试", company: "C", intentionLevel: "高", intentionScore: 90, lastFollowUpAt: "", phone: "", email: "", scoreReason: "", owner: "sales1", deleted: false },
    ];
    expect(getCustomerById(customers, "999")).toBeUndefined();
  });

  it("getCustomerById returns undefined for soft-deleted customer", () => {
    const customers: CustomerDetail[] = [
      { id: "1", name: "测试", company: "C", intentionLevel: "高", intentionScore: 90, lastFollowUpAt: "", phone: "", email: "", scoreReason: "", owner: "sales1", deleted: true },
    ];
    expect(getCustomerById(customers, "1")).toBeUndefined();
  });
});

describe("Boundary — out-of-range pagination", () => {
  it("page beyond total returns empty items but correct metadata", () => {
    const customers = getCustomers();
    const page = paginateCustomers(customers, 999, 5);
    expect(page.items).toEqual([]);
    expect(page.page).toBe(999);
    expect(page.total).toBe(customers.length);
  });

  it("page 0 returns items from start (clamped by slice)", () => {
    const customers = getCustomers();
    const page = paginateCustomers(customers, 0, 5);
    // slice(-5, 0) returns [], but this documents the behavior
    expect(page.items.length).toBeLessThanOrEqual(5);
  });

  it("pageSize larger than list returns all in one page", () => {
    const customers = getCustomers();
    const page = paginateCustomers(customers, 1, 999);
    expect(page.items.length).toBe(customers.length);
    expect(page.totalPages).toBe(1);
  });
});

describe("Boundary — missing required fields", () => {
  it("customer without company is still structurally valid", () => {
    const partial = { id: "x", name: "测试", company: "", intentionLevel: "中" as const, intentionScore: 50, lastFollowUpAt: new Date().toISOString(), phone: "", email: "", ownerUsername: "sales1", createdAt: new Date().toISOString() };
    // The app's import form rejects empty company; this test documents that
    // the data layer itself does not crash on empty strings.
    expect(filterCustomers([partial as Customer], { nameKeyword: "测试" }).length).toBe(1);
  });
});

describe("Boundary — lead validation", () => {
  it("rejects lead with empty company", () => {
    expect(validateLead({ company: "", contactName: "张三", phone: "", email: "", intentionLevel: "高" }).valid).toBe(false);
  });

  it("rejects lead with empty contactName", () => {
    expect(validateLead({ company: "阿里", contactName: "", phone: "", email: "", intentionLevel: "高" }).valid).toBe(false);
  });

  it("accepts valid lead", () => {
    expect(validateLead({ company: "阿里", contactName: "张三", phone: "", email: "", intentionLevel: "高" }).valid).toBe(true);
  });

  it("parseCsvToLeads returns empty for header-only CSV", () => {
    expect(parseCsvToLeads("公司名,联系人,电话,邮箱,意向等级\n")).toEqual([]);
  });

  it("parseCsvToLeads returns empty for empty string", () => {
    expect(parseCsvToLeads("")).toEqual([]);
  });

  it("parseCsvToLeads defaults invalid intention level to 低", () => {
    const leads = parseCsvToLeads("公司,联系人,电话,邮箱,意向\nA公司,B联系,111,e@x.com,超高\n");
    expect(leads.length).toBe(1);
    expect(leads[0].intentionLevel).toBe("低");
  });
});

describe("Boundary — RBAC with empty and single-item lists", () => {
  const sales: User = { username: "sales1", role: "sales", displayName: "张销售" };
  const admin: User = { username: "admin1", role: "admin", displayName: "管理员" };

  it("canAccessCustomer on empty array context still returns correct boolean", () => {
    const emptyCustomers: { ownerUsername: string }[] = [];
    const visible = emptyCustomers.filter((c) => canAccessCustomer(sales, c));
    expect(visible).toEqual([]);
  });

  it("canModifyCustomer returns false for sales on any customer", () => {
    const customers = getCustomers();
    for (const c of customers) {
      expect(canModifyCustomer(sales, c)).toBe(false);
    }
  });

  it("canModifyCustomer returns true for admin on any customer", () => {
    const customers = getCustomers();
    for (const c of customers) {
      expect(canModifyCustomer(admin, c)).toBe(true);
    }
  });
});

describe("Boundary — batchImportLeads with empty inputs", () => {
  it("importing zero leads into empty list yields zero imported", () => {
    const existing: Lead[] = [];
    const result = batchImportLeads(existing, []);
    expect(result.imported).toBe(0);
    expect(result.total).toBe(0);
    expect(existing).toHaveLength(0);
  });

  it("importing into existing list with no duplicates adds all", () => {
    const existing: Lead[] = [
      { company: "X", contactName: "Y", phone: "", email: "", intentionLevel: "低" },
    ];
    const result = batchImportLeads(existing, [
      { company: "A", contactName: "B", phone: "", email: "", intentionLevel: "高" },
    ]);
    expect(result.imported).toBe(1);
    expect(result.skipped).toBe(0);
    expect(existing).toHaveLength(2);
  });
});

describe("Boundary — parseCsvToLeads edge cases", () => {
  it("handles CSV with fewer than 5 columns per row", () => {
    const csv = "公司,联系人,电话,邮箱,意向\n只有三列,联系人,111\n";
    const leads = parseCsvToLeads(csv);
    expect(leads).toHaveLength(0);
  });

  it("handles CSV with empty company or contactName columns", () => {
    const csv = "公司,联系人,电话,邮箱,意向\n,空公司,111,e@x.com,高\n";
    const leads = parseCsvToLeads(csv);
    expect(leads).toHaveLength(0);
  });
});
