import { describe, it, expect, beforeEach } from "vitest";
import {
  parseCsvToLeads,
  detectDuplicates,
  generateTemplateBuffer,
  batchImportLeads,
  addLeadManually,
  validateLead,
  type Lead,
  type ImportResult,
} from "../src/lead-import.js";

const sampleCsv =
  "公司名,联系人,电话,邮箱,意向等级\n" +
  "阿里巴巴,张三,13800000001,zhangsan@alibaba.com,高\n" +
  "腾讯科技,李四,13800000002,lisi@tencent.com,中\n";

describe("parseCsvToLeads", () => {
  it("parses a valid CSV string into Lead objects", () => {
    const leads = parseCsvToLeads(sampleCsv);
    expect(leads.length).toBe(2);
    expect(leads[0].company).toBe("阿里巴巴");
    expect(leads[0].contactName).toBe("张三");
    expect(leads[0].phone).toBe("13800000001");
    expect(leads[0].email).toBe("zhangsan@alibaba.com");
    expect(leads[0].intentionLevel).toBe("高");
  });

  it("returns empty array for empty CSV", () => {
    expect(parseCsvToLeads("")).toEqual([]);
    expect(parseCsvToLeads("公司名,联系人,电话,邮箱,意向等级\n")).toEqual([]);
  });

  it("skips rows with missing required fields", () => {
    const csv =
      "公司名,联系人,电话,邮箱,意向等级\n" +
      "阿里巴巴,,13800000001,zhangsan@alibaba.com,高\n" +
      "腾讯科技,李四,13800000002,lisi@tencent.com,中\n";
    const leads = parseCsvToLeads(csv);
    expect(leads.length).toBe(1);
    expect(leads[0].company).toBe("腾讯科技");
  });
});

describe("detectDuplicates", () => {
  const existingLeads: Lead[] = [
    { company: "阿里巴巴", contactName: "张三", phone: "13800000001", email: "z@al.com", intentionLevel: "高" },
  ];

  it("detects duplicate by company + contactName", () => {
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "13900000001", email: "new@al.com", intentionLevel: "中" },
      { company: "腾讯科技", contactName: "李四", phone: "13800000002", email: "lisi@tencent.com", intentionLevel: "低" },
    ];
    const result = detectDuplicates(newLeads, existingLeads);
    expect(result.duplicates.length).toBe(1);
    expect(result.duplicates[0].lead.company).toBe("阿里巴巴");
    expect(result.duplicates[0].lead.contactName).toBe("张三");
    expect(result.unique.length).toBe(1);
    expect(result.unique[0].company).toBe("腾讯科技");
  });

  it("returns all unique when no duplicates", () => {
    const newLeads: Lead[] = [
      { company: "百度", contactName: "周八", phone: "13800000008", email: "zhouba@baidu.com", intentionLevel: "中" },
    ];
    const result = detectDuplicates(newLeads, existingLeads);
    expect(result.duplicates.length).toBe(0);
    expect(result.unique.length).toBe(1);
  });

  it("returns empty unique when all are duplicates", () => {
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "999", email: "x@x.com", intentionLevel: "低" },
    ];
    const result = detectDuplicates(newLeads, existingLeads);
    expect(result.duplicates.length).toBe(1);
    expect(result.unique.length).toBe(0);
  });

  it("default duplicateAction is skip", () => {
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "139", email: "x@x.com", intentionLevel: "低" },
    ];
    const result = detectDuplicates(newLeads, existingLeads);
    expect(result.duplicates[0].action).toBe("skip");
  });
});

describe("generateTemplateBuffer", () => {
  it("returns a Buffer (or Uint8Array) with xlsx magic bytes", () => {
    const buf = generateTemplateBuffer();
    expect(buf).toBeInstanceOf(Uint8Array);
    expect(buf.length).toBeGreaterThan(0);
    // XLSX files start with PK zip signature: 0x50 0x4B
    expect(buf[0]).toBe(0x50);
    expect(buf[1]).toBe(0x4b);
  });
});

describe("addLeadManually", () => {
  it("adds a valid lead to the list", () => {
    const leads: Lead[] = [];
    const result = addLeadManually(leads, {
      company: "阿里巴巴",
      contactName: "张三",
      phone: "13800000001",
      email: "z@al.com",
      intentionLevel: "高",
    });
    expect(result.success).toBe(true);
    expect(leads.length).toBe(1);
  });

  it("rejects lead with missing company", () => {
    const leads: Lead[] = [];
    const result = addLeadManually(leads, {
      company: "",
      contactName: "张三",
      phone: "13800000001",
      email: "z@al.com",
      intentionLevel: "高",
    });
    expect(result.success).toBe(false);
    expect(result.error).toContain("公司名");
  });

  it("rejects lead with missing contactName", () => {
    const leads: Lead[] = [];
    const result = addLeadManually(leads, {
      company: "阿里巴巴",
      contactName: "",
      phone: "13800000001",
      email: "z@al.com",
      intentionLevel: "高",
    });
    expect(result.success).toBe(false);
    expect(result.error).toContain("联系人");
  });

  it("detects duplicate in existing leads", () => {
    const leads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "13800000001", email: "z@al.com", intentionLevel: "高" },
    ];
    const result = addLeadManually(leads, {
      company: "阿里巴巴",
      contactName: "张三",
      phone: "13900000001",
      email: "new@al.com",
      intentionLevel: "中",
    });
    expect(result.success).toBe(false);
    expect(result.error).toContain("重复");
  });
});

describe("validateLead", () => {
  it("returns valid for complete lead", () => {
    const result = validateLead({
      company: "阿里巴巴",
      contactName: "张三",
      phone: "13800000001",
      email: "z@al.com",
      intentionLevel: "高",
    });
    expect(result.valid).toBe(true);
  });

  it("returns invalid for missing company", () => {
    const result = validateLead({
      company: "",
      contactName: "张三",
      phone: "13800000001",
      email: "z@al.com",
      intentionLevel: "高",
    });
    expect(result.valid).toBe(false);
    expect(result.error).toBeDefined();
  });

  it("returns invalid for missing contactName", () => {
    const result = validateLead({
      company: "阿里巴巴",
      contactName: "",
      phone: "13800000001",
      email: "z@al.com",
      intentionLevel: "高",
    });
    expect(result.valid).toBe(false);
  });
});

describe("batchImportLeads", () => {
  it("imports unique leads when no duplicates", () => {
    const existing: Lead[] = [];
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "13800000001", email: "z@al.com", intentionLevel: "高" },
      { company: "腾讯科技", contactName: "李四", phone: "13800000002", email: "lisi@tencent.com", intentionLevel: "中" },
    ];
    const result = batchImportLeads(existing, newLeads);
    expect(result.imported).toBe(2);
    expect(result.skipped).toBe(0);
    expect(result.overwritten).toBe(0);
    expect(existing.length).toBe(2);
  });

  it("skips duplicates by default", () => {
    const existing: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "13800000001", email: "z@al.com", intentionLevel: "高" },
    ];
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "139", email: "new@al.com", intentionLevel: "低" },
      { company: "腾讯科技", contactName: "李四", phone: "13800000002", email: "lisi@tencent.com", intentionLevel: "中" },
    ];
    const result = batchImportLeads(existing, newLeads);
    expect(result.imported).toBe(1);
    expect(result.skipped).toBe(1);
    expect(existing.length).toBe(2);
  });

  it("overwrites duplicates when action is overwrite", () => {
    const existing: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "13800000001", email: "z@al.com", intentionLevel: "高" },
    ];
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "13900000000", email: "new@al.com", intentionLevel: "低" },
    ];
    const result = batchImportLeads(existing, newLeads, { duplicateAction: "overwrite" });
    expect(result.imported).toBe(1);
    expect(result.overwritten).toBe(1);
    expect(result.skipped).toBe(0);
    const overwritten = existing.find((l) => l.company === "阿里巴巴" && l.contactName === "张三");
    expect(overwritten!.phone).toBe("13900000000");
  });

  it("returns summary with correct counts", () => {
    const existing: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "13800000001", email: "z@al.com", intentionLevel: "高" },
    ];
    const newLeads: Lead[] = [
      { company: "阿里巴巴", contactName: "张三", phone: "139", email: "new@al.com", intentionLevel: "低" },
      { company: "腾讯科技", contactName: "李四", phone: "13800000002", email: "lisi@tencent.com", intentionLevel: "中" },
      { company: "字节跳动", contactName: "王五", phone: "13800000003", email: "wangwu@bytedance.com", intentionLevel: "低" },
    ];
    const result = batchImportLeads(existing, newLeads);
    expect(result.total).toBe(3);
    expect(result.imported).toBe(2);
    expect(result.skipped).toBe(1);
    expect(result.summary).toBeDefined();
    expect(result.summary.length).toBeGreaterThan(0);
  });
});
