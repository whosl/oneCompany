import { describe, it, expect, beforeEach } from "vitest";
import { authenticate, getSession, logout, type User } from "../src/auth.js";
import {
  getCustomers,
  filterCustomers,
  sortCustomers,
  paginateCustomers,
  type Customer,
} from "../src/customers.js";
import { mockUsers, mockCustomers } from "../src/data.js";

describe("Authentication", () => {
  beforeEach(() => {
    logout();
  });

  it("rejects invalid credentials with error message", () => {
    const result = authenticate("wrong", "wrong");
    expect(result.success).toBe(false);
    expect(result.error).toBe("用户名或密码错误");
  });

  it("authenticates valid sales user and returns user with role", () => {
    const result = authenticate("sales1", "123456");
    expect(result.success).toBe(true);
    expect(result.user).toBeDefined();
    expect(result.user!.role).toBe("sales");
    expect(result.user!.username).toBe("sales1");
  });

  it("stores session after successful login", () => {
    authenticate("sales1", "123456");
    const session = getSession();
    expect(session).not.toBeNull();
    expect(session!.role).toBe("sales");
  });

  it("clears session on logout", () => {
    authenticate("sales1", "123456");
    logout();
    expect(getSession()).toBeNull();
  });

  it("returns correct redirect path for sales role", () => {
    const result = authenticate("sales1", "123456");
    expect(result.redirectTo).toBe("/customers");
  });

  it("returns correct redirect path for admin role", () => {
    const result = authenticate("admin1", "admin123");
    expect(result.redirectTo).toBe("/admin");
  });
});

describe("Customer data", () => {
  it("provides mock customer list with required fields", () => {
    const customers = getCustomers();
    expect(customers.length).toBeGreaterThan(0);
    const c = customers[0];
    expect(c).toHaveProperty("name");
    expect(c).toHaveProperty("company");
    expect(c).toHaveProperty("intentionLevel");
    expect(c).toHaveProperty("intentionScore");
    expect(c).toHaveProperty("lastFollowUpAt");
  });

  it("includes customers with all three intention levels", () => {
    const customers = getCustomers();
    const levels = new Set(customers.map((c) => c.intentionLevel));
    expect(levels.has("高")).toBe(true);
    expect(levels.has("中")).toBe(true);
    expect(levels.has("低")).toBe(true);
  });
});

describe("Customer filtering", () => {
  let allCustomers: Customer[];

  beforeEach(() => {
    allCustomers = getCustomers();
  });

  it("filters by name keyword (fuzzy search)", () => {
    const result = filterCustomers(allCustomers, { nameKeyword: "张" });
    expect(result.length).toBeGreaterThan(0);
    expect(result.every((c) => c.name.includes("张"))).toBe(true);
  });

  it("returns empty array when no match", () => {
    const result = filterCustomers(allCustomers, {
      nameKeyword: "不存在的人名XYZ",
    });
    expect(result).toEqual([]);
  });

  it("filters by intention level", () => {
    const result = filterCustomers(allCustomers, { intentionLevel: "高" });
    expect(result.length).toBeGreaterThan(0);
    expect(result.every((c) => c.intentionLevel === "高")).toBe(true);
  });

  it("filters by both name and intention level", () => {
    const result = filterCustomers(allCustomers, {
      nameKeyword: "张",
      intentionLevel: "高",
    });
    expect(
      result.every(
        (c) => c.name.includes("张") && c.intentionLevel === "高"
      )
    ).toBe(true);
  });

  it("returns all customers when filters are empty", () => {
    const result = filterCustomers(allCustomers, {});
    expect(result.length).toBe(allCustomers.length);
  });
});

describe("Customer sorting", () => {
  let allCustomers: Customer[];

  beforeEach(() => {
    allCustomers = getCustomers();
  });

  it("sorts by intentionScore descending by default", () => {
    const sorted = sortCustomers(allCustomers, "intentionScore", "desc");
    for (let i = 1; i < sorted.length; i++) {
      expect(sorted[i].intentionScore).toBeLessThanOrEqual(
        sorted[i - 1].intentionScore
      );
    }
  });

  it("sorts by intentionScore ascending", () => {
    const sorted = sortCustomers(allCustomers, "intentionScore", "asc");
    for (let i = 1; i < sorted.length; i++) {
      expect(sorted[i].intentionScore).toBeGreaterThanOrEqual(
        sorted[i - 1].intentionScore
      );
    }
  });

  it("sorts by lastFollowUpAt descending (default list order)", () => {
    const sorted = sortCustomers(allCustomers, "lastFollowUpAt", "desc");
    for (let i = 1; i < sorted.length; i++) {
      expect(
        new Date(sorted[i].lastFollowUpAt).getTime()
      ).toBeLessThanOrEqual(
        new Date(sorted[i - 1].lastFollowUpAt).getTime()
      );
    }
  });
});

describe("Customer pagination", () => {
  let allCustomers: Customer[];

  beforeEach(() => {
    allCustomers = getCustomers();
  });

  it("returns correct page of customers", () => {
    const page = paginateCustomers(allCustomers, 1, 5);
    expect(page.items.length).toBeLessThanOrEqual(5);
    expect(page.total).toBe(allCustomers.length);
    expect(page.page).toBe(1);
    expect(page.pageSize).toBe(5);
  });

  it("returns different items on different pages", () => {
    if (allCustomers.length > 5) {
      const page1 = paginateCustomers(allCustomers, 1, 5);
      const page2 = paginateCustomers(allCustomers, 2, 5);
      expect(page1.items[0].name).not.toBe(page2.items[0].name);
    }
  });

  it("calculates total pages correctly", () => {
    const page = paginateCustomers(allCustomers, 1, 5);
    expect(page.totalPages).toBe(Math.ceil(allCustomers.length / 5));
  });
});
