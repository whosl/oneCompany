import { describe, it, expect } from "vitest";
import {
  canAccessCustomer,
  canModifyCustomer,
  type User,
} from "../src/auth.js";
import { seedCustomers } from "../src/seed.js";

const sales1: User = { username: "sales1", role: "sales", displayName: "张销售" };
const sales2: User = { username: "sales2", role: "sales", displayName: "李销售" };
const manager1: User = { username: "manager1", role: "manager", displayName: "王经理" };
const admin1: User = { username: "admin1", role: "admin", displayName: "管理员" };

const customerOwnedBySales1 = { ownerUsername: "sales1" };
const customerOwnedBySales2 = { ownerUsername: "sales2" };

describe("canAccessCustomer — view authorization", () => {
  it("sales can view their own customer", () => {
    expect(canAccessCustomer(sales1, customerOwnedBySales1)).toBe(true);
  });

  it("sales cannot view another rep's customer (cross-tenant isolation)", () => {
    expect(canAccessCustomer(sales1, customerOwnedBySales2)).toBe(false);
    expect(canAccessCustomer(sales2, customerOwnedBySales1)).toBe(false);
  });

  it("manager can view all customers", () => {
    expect(canAccessCustomer(manager1, customerOwnedBySales1)).toBe(true);
    expect(canAccessCustomer(manager1, customerOwnedBySales2)).toBe(true);
  });

  it("admin can view all customers", () => {
    expect(canAccessCustomer(admin1, customerOwnedBySales1)).toBe(true);
    expect(canAccessCustomer(admin1, customerOwnedBySales2)).toBe(true);
  });
});

describe("canAccessCustomer — seed data cross-tenant check", () => {
  it("sales1 is blocked from sales2's seed customers", () => {
    const sales2Customers = seedCustomers.filter((c) => c.ownerUsername === "sales2");
    expect(sales2Customers.length).toBeGreaterThan(0);
    for (const c of sales2Customers) {
      expect(canAccessCustomer(sales1, c)).toBe(false);
    }
  });

  it("sales2 is blocked from sales1's seed customers", () => {
    const sales1Customers = seedCustomers.filter((c) => c.ownerUsername === "sales1");
    expect(sales1Customers.length).toBeGreaterThan(0);
    for (const c of sales1Customers) {
      expect(canAccessCustomer(sales2, c)).toBe(false);
    }
  });

  it("manager can access all seed customers", () => {
    for (const c of seedCustomers) {
      expect(canAccessCustomer(manager1, c)).toBe(true);
    }
  });

  it("admin can access all seed customers", () => {
    for (const c of seedCustomers) {
      expect(canAccessCustomer(admin1, c)).toBe(true);
    }
  });
});

describe("canAccessCustomer — detail page access denial simulation", () => {
  it("sales1 accessing sales2 customer returns false (blocked at detail page)", () => {
    const sales2Customer = seedCustomers.find((c) => c.ownerUsername === "sales2")!;
    expect(sales2Customer).toBeDefined();
    expect(canAccessCustomer(sales1, sales2Customer)).toBe(false);
  });

  it("non-existent customer lookup returns undefined", () => {
    const found = seedCustomers.find((c) => c.id === "non-existent-999");
    expect(found).toBeUndefined();
  });
});

describe("canModifyCustomer — write authorization", () => {
  it("sales cannot modify (delete/reassign/rescore)", () => {
    expect(canModifyCustomer(sales1, customerOwnedBySales1)).toBe(false);
    expect(canModifyCustomer(sales2, customerOwnedBySales2)).toBe(false);
  });

  it("manager can modify any customer", () => {
    expect(canModifyCustomer(manager1, customerOwnedBySales1)).toBe(true);
    expect(canModifyCustomer(manager1, customerOwnedBySales2)).toBe(true);
  });

  it("admin can modify any customer", () => {
    expect(canModifyCustomer(admin1, customerOwnedBySales1)).toBe(true);
  });

  it("sales cannot modify even their own customers", () => {
    const ownCustomer = seedCustomers.find((c) => c.ownerUsername === "sales1")!;
    expect(canModifyCustomer(sales1, ownCustomer)).toBe(false);
  });
});

describe("Acceptance — AC1: sales1 cannot view sales2's customer", () => {
  it("canAccessCustomer(sales1, sales2Customer) returns false", () => {
    const sales2Customer = seedCustomers.find((c) => c.ownerUsername === "sales2")!;
    expect(canAccessCustomer(sales1, sales2Customer)).toBe(false);
  });

  it("every sales2-owned seed customer is inaccessible to sales1", () => {
    const blocked = seedCustomers.filter((c) => c.ownerUsername === "sales2");
    expect(blocked.length).toBeGreaterThan(0);
    expect(blocked.every((c) => !canAccessCustomer(sales1, c))).toBe(true);
  });
});

describe("Acceptance — AC2: manager and admin can view all customers", () => {
  it("manager1 can access every seed customer regardless of owner", () => {
    expect(seedCustomers.length).toBeGreaterThan(0);
    for (const c of seedCustomers) {
      expect(canAccessCustomer(manager1, c)).toBe(true);
    }
  });

  it("admin1 can access every seed customer regardless of owner", () => {
    for (const c of seedCustomers) {
      expect(canAccessCustomer(admin1, c)).toBe(true);
    }
  });
});

describe("Acceptance — AC5: unauthorized access to customer detail is blocked", () => {
  it("sales1 is denied access to a sales2-owned customer detail", () => {
    const target = seedCustomers.find((c) => c.ownerUsername === "sales2")!;
    expect(target).toBeDefined();
    expect(canAccessCustomer(sales1, target)).toBe(false);
  });

  it("manager retains access to same customer", () => {
    const target = seedCustomers.find((c) => c.ownerUsername === "sales2")!;
    expect(canAccessCustomer(manager1, target)).toBe(true);
  });

  it("canModifyCustomer denies sales role for all customers", () => {
    for (const c of seedCustomers) {
      expect(canModifyCustomer(sales1, c)).toBe(false);
    }
  });
});
