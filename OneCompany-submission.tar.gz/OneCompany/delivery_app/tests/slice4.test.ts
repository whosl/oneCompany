import { describe, it, expect } from "vitest";
import {
  computeTeamOverview,
  computeIntentionDistribution,
  computeMemberRanking,
  computeTrendData,
  filterByTimeRange,
  type CustomerRecord,
  type TeamOverview,
  type IntentionDistribution,
  type MemberRank,
  type TrendPoint,
} from "../src/statistics.js";

const baseCustomers: CustomerRecord[] = [
  { id: "1", name: "张三", company: "阿里巴巴", intentionLevel: "高", intentionScore: 95, lastFollowUpAt: "2026-06-13T10:00:00Z", phone: "13800000001", email: "z@al.com", ownerUsername: "sales1", createdAt: "2026-06-01T08:00:00Z" },
  { id: "2", name: "李四", company: "腾讯科技", intentionLevel: "高", intentionScore: 88, lastFollowUpAt: "2026-06-12T14:30:00Z", phone: "13800000002", email: "l@tx.com", ownerUsername: "sales1", createdAt: "2026-06-02T09:00:00Z" },
  { id: "3", name: "王五", company: "字节跳动", intentionLevel: "中", intentionScore: 72, lastFollowUpAt: "2026-06-11T09:15:00Z", phone: "13800000003", email: "w@bd.com", ownerUsername: "sales2", createdAt: "2026-06-03T10:00:00Z" },
  { id: "4", name: "赵六", company: "美团", intentionLevel: "低", intentionScore: 45, lastFollowUpAt: "2026-06-10T16:45:00Z", phone: "13800000004", email: "z@mt.com", ownerUsername: "sales2", createdAt: "2026-06-05T11:00:00Z" },
  { id: "5", name: "张伟", company: "京东集团", intentionLevel: "中", intentionScore: 68, lastFollowUpAt: "2026-06-09T11:20:00Z", phone: "13800000005", email: "z@jd.com", ownerUsername: "sales1", createdAt: "2026-05-20T08:00:00Z" },
  { id: "6", name: "孙七", company: "华为技术", intentionLevel: "高", intentionScore: 91, lastFollowUpAt: "2026-06-08T08:00:00Z", phone: "13800000006", email: "s@hw.com", ownerUsername: "sales2", createdAt: "2026-05-15T09:00:00Z" },
  { id: "7", name: "周八", company: "小米科技", intentionLevel: "低", intentionScore: 38, lastFollowUpAt: "2026-06-07T15:30:00Z", phone: "13800000007", email: "z@mi.com", ownerUsername: "sales1", createdAt: "2026-06-10T07:00:00Z" },
];

describe("computeTeamOverview", () => {
  it("returns totalLeadCount equal to customer array length", () => {
    const overview = computeTeamOverview(baseCustomers);
    expect(overview.totalLeadCount).toBe(7);
  });

  it("returns correct counts by intention level", () => {
    const overview = computeTeamOverview(baseCustomers);
    expect(overview.highCount).toBe(3);
    expect(overview.mediumCount).toBe(2);
    expect(overview.lowCount).toBe(2);
  });

  it("computes conversionRate as highCount / totalLeadCount", () => {
    const overview = computeTeamOverview(baseCustomers);
    expect(overview.conversionRate).toBeCloseTo(3 / 7);
  });

  it("returns 0 conversionRate for empty customers", () => {
    const overview = computeTeamOverview([]);
    expect(overview.conversionRate).toBe(0);
  });

  it("counts newThisMonth based on createdAt in current month", () => {
    const overview = computeTeamOverview(baseCustomers);
    // All 7 have createdAt in May or June 2026; "this month" is relative to referenceDate
    const overviewWithRef = computeTeamOverview(baseCustomers, "2026-06-15T00:00:00Z");
    // June customers: id 1,2,3,4,7 = 5
    expect(overviewWithRef.newThisMonth).toBe(5);
  });
});

describe("computeIntentionDistribution", () => {
  it("returns counts for each intention level", () => {
    const dist = computeIntentionDistribution(baseCustomers);
    expect(dist).toEqual([
      { level: "高", count: 3 },
      { level: "中", count: 2 },
      { level: "低", count: 2 },
    ]);
  });

  it("returns zero counts for empty input", () => {
    const dist = computeIntentionDistribution([]);
    expect(dist).toEqual([
      { level: "高", count: 0 },
      { level: "中", count: 0 },
      { level: "低", count: 0 },
    ]);
  });
});

describe("computeMemberRanking", () => {
  it("returns ranking sorted by customer count descending", () => {
    const ranking = computeMemberRanking(baseCustomers, [
      { username: "sales1", displayName: "张销售" },
      { username: "sales2", displayName: "李销售" },
    ]);
    expect(ranking[0].displayName).toBe("张销售");
    expect(ranking[0].count).toBe(4);
    expect(ranking[1].displayName).toBe("李销售");
    expect(ranking[1].count).toBe(3);
  });

  it("includes members with zero customers", () => {
    const ranking = computeMemberRanking(baseCustomers, [
      { username: "sales1", displayName: "张销售" },
      { username: "sales2", displayName: "李销售" },
      { username: "sales3", displayName: "赵销售" },
    ]);
    expect(ranking.length).toBe(3);
    const sales3 = ranking.find((r) => r.username === "sales3");
    expect(sales3?.count).toBe(0);
  });
});

describe("computeTrendData", () => {
  it("returns daily new lead counts within date range", () => {
    const trend = computeTrendData(baseCustomers, "2026-06-01", "2026-06-05");
    expect(trend.length).toBe(5);
    expect(trend[0]).toEqual({ date: "2026-06-01", count: 1 });
    expect(trend[1]).toEqual({ date: "2026-06-02", count: 1 });
    expect(trend[2]).toEqual({ date: "2026-06-03", count: 1 });
    expect(trend[3]).toEqual({ date: "2026-06-04", count: 0 });
    expect(trend[4]).toEqual({ date: "2026-06-05", count: 1 });
  });

  it("returns empty array for empty customers", () => {
    const trend = computeTrendData([], "2026-06-01", "2026-06-03");
    expect(trend.length).toBe(3);
    expect(trend.every((p) => p.count === 0)).toBe(true);
  });
});

describe("filterByTimeRange", () => {
  it("filters customers by createdAt within range", () => {
    const filtered = filterByTimeRange(baseCustomers, "2026-06-01", "2026-06-05");
    expect(filtered.length).toBe(4);
    expect(filtered.every((c) => c.createdAt >= "2026-06-01" && c.createdAt <= "2026-06-06T00:00:00Z")).toBe(true);
  });

  it("returns all customers when no range specified", () => {
    const filtered = filterByTimeRange(baseCustomers);
    expect(filtered.length).toBe(7);
  });
});
