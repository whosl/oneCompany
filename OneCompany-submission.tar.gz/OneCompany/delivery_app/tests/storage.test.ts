import { describe, it, expect, beforeEach } from "vitest";
import { loadCustomers, saveCustomers, resetCustomers } from "../src/storage.js";
import { batchImportLeads, addLeadManually, type Lead } from "../src/lead-import.js";

function createMockStorage(): Storage {
  const map = new Map<string, string>();
  return {
    get length() { return map.size; },
    clear() { map.clear(); },
    getItem(key: string) { return map.get(key) ?? null; },
    setItem(key: string, value: string) { map.set(key, value); },
    removeItem(key: string) { map.delete(key); },
    key(index: number) { return [...map.keys()][index] ?? null; },
  };
}

describe("Customer persistence (localStorage)", () => {
  let storage: Storage;

  beforeEach(() => {
    storage = createMockStorage();
  });

  it("seeds on first run and persists to storage", () => {
    const first = loadCustomers(storage);
    expect(first.length).toBe(10);

    const second = loadCustomers(storage);
    expect(second.length).toBe(10);
    expect(second[0].name).toBe(first[0].name);
  });

  it("round-trips save → load", () => {
    const original = loadCustomers(storage);
    original[0].name = "改名测试";
    saveCustomers(storage, original);

    const reloaded = loadCustomers(storage);
    expect(reloaded[0].name).toBe("改名测试");
  });

  it("survives a simulated refresh (data retained)", () => {
    const data = loadCustomers(storage);
    data.push({
      id: "999",
      name: "新客户",
      company: "新公司",
      intentionLevel: "高",
      intentionScore: 90,
      lastFollowUpAt: new Date().toISOString(),
      phone: "13900000000",
      email: "new@test.com",
      ownerUsername: "sales1",
      createdAt: new Date().toISOString(),
    });
    saveCustomers(storage, data);

    const afterRefresh = loadCustomers(storage);
    expect(afterRefresh.length).toBe(11);
    expect(afterRefresh.find((c) => c.id === "999")).toBeDefined();
  });

  it("resetCustomers restores seed data", () => {
    const data = loadCustomers(storage);
    data.length = 0;
    saveCustomers(storage, data);
    expect(loadCustomers(storage)).toHaveLength(0);

    const restored = resetCustomers(storage);
    expect(restored.length).toBe(10);
    expect(loadCustomers(storage).length).toBe(10);
  });

  it("handles corrupted storage gracefully (falls back to seed)", () => {
    storage.setItem("crm_customers", "{ invalid json");
    const result = loadCustomers(storage);
    expect(result.length).toBe(10);
  });
});

describe("Lead import persistence simulation", () => {
  let storage: Storage;

  beforeEach(() => {
    storage = createMockStorage();
  });

  it("manually added lead can be persisted to storage and survives refresh", () => {
    const leads: Lead[] = loadCustomers(storage).map((c) => ({
      company: c.company,
      contactName: c.name,
      phone: c.phone,
      email: c.email,
      intentionLevel: c.intentionLevel,
    }));

    const result = addLeadManually(leads, {
      company: "新公司ABC",
      contactName: "新联系人",
      phone: "13900001111",
      email: "new@abc.com",
      intentionLevel: "高",
    });
    expect(result.success).toBe(true);

    const leadsKey = "crm_leads";
    storage.setItem(leadsKey, JSON.stringify(leads));

    const reloaded = JSON.parse(storage.getItem(leadsKey)!);
    expect(reloaded.some((l: Lead) => l.company === "新公司ABC")).toBe(true);
  });

  it("batch imported leads persist after simulated refresh", () => {
    const existing: Lead[] = [];
    const newLeads: Lead[] = [
      { company: "公司A", contactName: "联系A", phone: "111", email: "a@x.com", intentionLevel: "高" },
      { company: "公司B", contactName: "联系B", phone: "222", email: "b@x.com", intentionLevel: "中" },
    ];

    const result = batchImportLeads(existing, newLeads);
    expect(result.imported).toBe(2);

    const leadsKey = "crm_leads";
    storage.setItem(leadsKey, JSON.stringify(existing));

    const reloaded: Lead[] = JSON.parse(storage.getItem(leadsKey)!);
    expect(reloaded.length).toBe(2);
    expect(reloaded[0].company).toBe("公司A");
    expect(reloaded[1].company).toBe("公司B");
  });

  it("customer data and lead data can coexist in storage independently", () => {
    const customers = loadCustomers(storage);
    expect(customers.length).toBe(10);

    const leads: Lead[] = [{ company: "X", contactName: "Y", phone: "", email: "", intentionLevel: "低" }];
    storage.setItem("crm_leads", JSON.stringify(leads));

    const reloadedCustomers = loadCustomers(storage);
    const reloadedLeads: Lead[] = JSON.parse(storage.getItem("crm_leads")!);
    expect(reloadedCustomers.length).toBe(10);
    expect(reloadedLeads.length).toBe(1);
  });
});

describe("Acceptance — AC3: customer data persists to localStorage and survives refresh", () => {
  let storage: Storage;

  beforeEach(() => {
    storage = createMockStorage();
  });

  it("data written via saveCustomers is retrievable after simulated page refresh", () => {
    loadCustomers(storage);
    const modified = loadCustomers(storage);
    modified[0].name = "刷新后保留";
    saveCustomers(storage, modified);

    const afterRefresh = loadCustomers(storage);
    expect(afterRefresh[0].name).toBe("刷新后保留");
  });

  it("newly added customer persists across storage re-reads", () => {
    const data = loadCustomers(storage);
    data.push({
      id: "new-1",
      name: "新增客户",
      company: "测试公司",
      intentionLevel: "高",
      intentionScore: 80,
      lastFollowUpAt: new Date().toISOString(),
      phone: "13900009999",
      email: "new@test.com",
      ownerUsername: "sales1",
      createdAt: new Date().toISOString(),
    });
    saveCustomers(storage, data);

    const reloaded = loadCustomers(storage);
    expect(reloaded.find((c) => c.id === "new-1")).toBeDefined();
    expect(reloaded.find((c) => c.id === "new-1")!.name).toBe("新增客户");
  });

  it("corrupted JSON falls back to seed instead of crashing", () => {
    storage.setItem("crm_customers", "not-json");
    const result = loadCustomers(storage);
    expect(result.length).toBe(10);
    expect(result[0].name).toBeDefined();
  });
});

describe("Acceptance — AC4: manual entry and batch import leads persist", () => {
  let storage: Storage;

  beforeEach(() => {
    storage = createMockStorage();
  });

  it("manually entered lead persists to crm_leads key", () => {
    const leads: Lead[] = [];
    addLeadManually(leads, {
      company: "手动录入公司",
      contactName: "手动联系人",
      phone: "13800001234",
      email: "manual@test.com",
      intentionLevel: "高",
    });

    storage.setItem("crm_leads", JSON.stringify(leads));
    const reloaded: Lead[] = JSON.parse(storage.getItem("crm_leads")!);
    expect(reloaded).toHaveLength(1);
    expect(reloaded[0].company).toBe("手动录入公司");
  });

  it("batch imported leads persist in crm_leads key", () => {
    const existing: Lead[] = [];
    batchImportLeads(existing, [
      { company: "批量A", contactName: "A", phone: "", email: "", intentionLevel: "高" },
      { company: "批量B", contactName: "B", phone: "", email: "", intentionLevel: "中" },
      { company: "批量C", contactName: "C", phone: "", email: "", intentionLevel: "低" },
    ]);

    storage.setItem("crm_leads", JSON.stringify(existing));
    const reloaded: Lead[] = JSON.parse(storage.getItem("crm_leads")!);
    expect(reloaded).toHaveLength(3);
  });

  it("manual entry + batch import accumulate in same storage key", () => {
    const leads: Lead[] = [];
    addLeadManually(leads, {
      company: "手动",
      contactName: "手",
      phone: "",
      email: "",
      intentionLevel: "高",
    });
    batchImportLeads(leads, [
      { company: "批量", contactName: "批", phone: "", email: "", intentionLevel: "中" },
    ]);

    storage.setItem("crm_leads", JSON.stringify(leads));
    const reloaded: Lead[] = JSON.parse(storage.getItem("crm_leads")!);
    expect(reloaded).toHaveLength(2);
  });
});
