# AI 销售线索管理助手

> 由 OneCompany 多智能体平台自动生成。项目 ID: `c124714a-0eb2-48ea-b7c6-d4f134c1198e`

销售人员可以导入客户线索，系统自动判断客户意向等级并生成评分，记录跟进历史。普通销售只能查看自己的客户，销售主管可以查看团队全部客户数据和统计。

## 功能清单

- **客户列表**：搜索、按意向等级筛选、评分排序、分页
- **客户详情**：意向评分及依据、跟进记录、AI 重新评分
- **数据统计**：线索总数、意向分布饼图、转化率、成员排名柱状图、新增趋势折线图
- **线索导入**：手动录入 + CSV 批量导入（含查重、覆盖/跳过策略）
- **角色权限**：sales / manager / admin 三角色，数据隔离 + 操作权限分级
- **数据持久化**：客户数据存储在浏览器 localStorage，刷新后保留

## 技术栈

- 纯前端多页面应用（MPA）：HTML + 原生 JavaScript（ES Modules）
- 手写静态文件服务器（`scripts/dev-server.mjs`，无 Express）
- TypeScript 类型定义（`src/`，仅用于测试和类型检查）
- Vitest 单元测试（happy-dom 环境）+ Playwright E2E

## 测试账号

| 用户名 | 密码 | 角色 | 可见范围 |
|---|---|---|---|
| `sales1` | `123456` | 销售 | 仅自己的客户 |
| `sales2` | `123456` | 销售 | 仅自己的客户 |
| `manager1` | `123456` | 销售主管 | 全部客户 |
| `admin1` | `admin123` | 管理员 | 全部客户 |

## 运行方式

```bash
pnpm install
pnpm dev          # 启动预览服务器 → http://127.0.0.1:3000
```

验证：

```bash
pnpm verify       # typecheck + test + build
```

Docker：

```bash
docker compose up --build
```

## 项目结构

```
├── src/                  # TypeScript 类型定义与纯函数（测试对象）
│   ├── auth.ts           # 认证 + 鉴权守卫（canAccessCustomer / canModifyCustomer）
│   ├── customers.ts      # 客户数据模型与过滤/排序/分页函数
│   ├── storage.ts        # localStorage 持久化（load/save/reset）
│   ├── seed.ts           # 初始种子数据
│   └── ...
├── public/js/            # 浏览器实际运行逻辑
│   ├── auth.js           # sessionStorage 会话 + requireAuth 守卫
│   ├── data.js           # localStorage 读写 + 鉴权函数
│   ├── customers.js      # 客户列表（按角色过滤）
│   ├── statistics.js     # 数据统计（按角色过滤）
│   └── ...
├── tests/                # Vitest 单元测试
│   ├── slice1-4.test.ts  # 原有切片测试
│   ├── authz.test.ts     # 越权测试（L3-RBAC）
│   ├── storage.test.ts   # 持久化测试（L3-DATA）
│   └── boundary.test.ts  # 边界测试（L3-BOUNDARY）
├── e2e/                  # Playwright 冒烟测试
├── *.html                # 页面（login/customers/customer-detail/statistics/import）
└── scripts/dev-server.mjs
```
