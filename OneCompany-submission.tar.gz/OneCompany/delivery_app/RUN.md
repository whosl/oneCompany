# Run Instructions

## Local verification

```bash
pnpm install
pnpm verify
```

## Browser preview

```bash
pnpm dev
# open http://127.0.0.1:3000 (or the PORT shown in the terminal)
```

Individual steps:

```bash
pnpm typecheck
pnpm test
pnpm build
```

## Docker

```bash
docker compose up --build
```

If the generated app references third-party API keys, provide them through a local
`.env` file. Missing keys should use mock data until real credentials are supplied.