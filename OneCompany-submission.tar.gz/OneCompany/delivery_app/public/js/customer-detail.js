import { requireAuth, logout, getSession } from "./auth.js";
import { customers as allCustomers, canAccessCustomer, canModifyCustomer } from "./data.js";

const session = requireAuth();
if (!session) throw new Error("redirected");

document.getElementById("userName").textContent = session.displayName;
document.getElementById("logoutBtn").addEventListener("click", logout);

const urlParams = new URLSearchParams(window.location.search);
const customerId = urlParams.get("id");

if (!customerId) {
  document.getElementById("loadingState").style.display = "none";
  document.getElementById("notFoundState").style.display = "block";
  throw new Error("no id");
}

const customer = allCustomers.find((c) => c.id === customerId);
if (!customer) {
  document.getElementById("loadingState").style.display = "none";
  document.getElementById("notFoundState").style.display = "block";
  throw new Error("not found");
}

if (!canAccessCustomer(session, customer)) {
  document.getElementById("loadingState").style.display = "none";
  document.getElementById("notFoundState").textContent = "无权访问该客户";
  document.getElementById("notFoundState").style.display = "block";
  throw new Error("unauthorized");
}

const customerDetail = {
  ...customer,
  scoreReason: "客户沟通频繁，表达明确采购意向，近期有明确需求反馈",
  owner: "sales1",
  deleted: false,
};

const followUps = [
  {
    id: "f1",
    customerId: customer.id,
    content: "初次电话沟通，了解客户需求",
    method: "电话",
    createdBy: "sales1",
    createdAt: "2026-06-10T10:00:00Z",
  },
  {
    id: "f2",
    customerId: customer.id,
    content: "发送产品方案和报价",
    method: "邮件",
    createdBy: "sales1",
    createdAt: "2026-06-12T14:00:00Z",
  },
];

let nextFollowUpId = 3;

function formatDate(iso) {
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  const h = String(d.getHours()).padStart(2, "0");
  const min = String(d.getMinutes()).padStart(2, "0");
  return `${y}-${m}-${day} ${h}:${min}`;
}

function renderDetail() {
  document.getElementById("loadingState").style.display = "none";
  document.getElementById("detailContent").style.display = "block";

  document.getElementById("customer-name").textContent = customerDetail.name;
  document.getElementById("customer-company").textContent = customerDetail.company;
  document.getElementById("customer-phone").textContent = customerDetail.phone;
  document.getElementById("customer-email").textContent = customerDetail.email;

  renderScore();
  renderTimeline();

  if (canModifyCustomer(session)) {
    document.getElementById("admin-actions").style.display = "flex";
    populateReassignOptions();
  }
}

function renderScore() {
  document.getElementById("score-level").textContent = customerDetail.intentionLevel;
  document.getElementById("score-level").className = `score-level level-${customerDetail.intentionLevel}`;
  document.getElementById("score-value").textContent = `${customerDetail.intentionScore}分`;
  document.getElementById("score-reason").textContent = `评分依据：${customerDetail.scoreReason}`;
}

function renderTimeline() {
  const timeline = document.getElementById("followUpTimeline");
  const sorted = [...followUps].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  if (sorted.length === 0) {
    timeline.innerHTML = '<div class="empty-state">暂无跟进记录</div>';
    return;
  }
  timeline.innerHTML = sorted
    .map(
      (f) => `
    <div class="timeline-item" data-testid="timeline-item">
      <div class="timeline-dot"></div>
      <div class="timeline-content">
        <div class="timeline-header">
          <span class="timeline-method method-${f.method}">${f.method}</span>
          <span class="timeline-date">${formatDate(f.createdAt)}</span>
          <span class="timeline-author">${f.createdBy}</span>
        </div>
        <p class="timeline-text">${f.content}</p>
      </div>
    </div>
  `
    )
    .join("");
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.style.display = "block";
  setTimeout(() => {
    toast.style.display = "none";
  }, 3000);
}

document.getElementById("regenerateBtn").addEventListener("click", () => {
  const btn = document.getElementById("regenerateBtn");
  const loading = document.getElementById("regenerateLoading");
  btn.style.display = "none";
  loading.style.display = "block";

  setTimeout(() => {
    const hash = Array.from(customer.id).reduce(
      (h, ch) => (h * 31 + ch.charCodeAt(0)) & 0xffffff,
      0
    );
    const score = 40 + (hash % 56);
    let level;
    if (score >= 80) level = "高";
    else if (score >= 60) level = "中";
    else level = "低";
    const reasons = [
      "根据近期沟通频率和客户反馈综合评估",
      "基于客户行业趋势和历史合作数据分析",
      "结合客户活跃度和购买意向模型推算",
      "依据最近互动记录和需求匹配度评定",
    ];
    customerDetail.intentionLevel = level;
    customerDetail.intentionScore = score;
    customerDetail.scoreReason = reasons[hash % reasons.length];

    renderScore();
    loading.style.display = "none";
    btn.style.display = "inline-flex";
    showToast("AI评分已更新");
  }, 1000);
});

const followUpModal = document.getElementById("followUpModal");
const followUpForm = document.getElementById("followUpForm");
const followUpError = document.getElementById("followUpError");

document.getElementById("addFollowUpBtn").addEventListener("click", () => {
  followUpForm.reset();
  followUpError.style.display = "none";
  followUpModal.style.display = "flex";
});

document.getElementById("cancelFollowUp").addEventListener("click", () => {
  followUpModal.style.display = "none";
});

followUpModal.addEventListener("click", (e) => {
  if (e.target === followUpModal) followUpModal.style.display = "none";
});

followUpForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const method = document.getElementById("followUpMethod").value;
  const content = document.getElementById("followUpContent").value.trim();

  if (!method) {
    followUpError.textContent = "请选择跟进方式";
    followUpError.style.display = "block";
    return;
  }
  if (!content) {
    followUpError.textContent = "跟进内容不能为空";
    followUpError.style.display = "block";
    return;
  }

  followUps.push({
    id: `f${nextFollowUpId++}`,
    customerId: customer.id,
    content,
    method,
    createdBy: session.username,
    createdAt: new Date().toISOString(),
  });

  followUpModal.style.display = "none";
  renderTimeline();
  showToast("跟进记录已添加");
});

const deleteModal = document.getElementById("deleteModal");

document.getElementById("deleteBtn").addEventListener("click", () => {
  deleteModal.style.display = "flex";
});

document.getElementById("cancelDelete").addEventListener("click", () => {
  deleteModal.style.display = "none";
});

deleteModal.addEventListener("click", (e) => {
  if (e.target === deleteModal) deleteModal.style.display = "none";
});

document.getElementById("confirmDelete").addEventListener("click", () => {
  customerDetail.deleted = true;
  deleteModal.style.display = "none";
  showToast("客户已删除");
  setTimeout(() => {
    window.location.href = "/customers.html";
  }, 1000);
});

const reassignModal = document.getElementById("reassignModal");

function populateReassignOptions() {
  const select = document.getElementById("newOwner");
  const salesUsers = [
    { username: "sales1", displayName: "张销售" },
    { username: "sales2", displayName: "李销售" },
  ];
  select.innerHTML = '<option value="">请选择</option>';
  salesUsers
    .filter((u) => u.username !== customerDetail.owner)
    .forEach((u) => {
      const opt = document.createElement("option");
      opt.value = u.username;
      opt.textContent = u.displayName;
      select.appendChild(opt);
    });
}

document.getElementById("reassignBtn").addEventListener("click", () => {
  populateReassignOptions();
  document.getElementById("reassignError").style.display = "none";
  reassignModal.style.display = "flex";
});

document.getElementById("cancelReassign").addEventListener("click", () => {
  reassignModal.style.display = "none";
});

reassignModal.addEventListener("click", (e) => {
  if (e.target === reassignModal) reassignModal.style.display = "none";
});

document.getElementById("confirmReassign").addEventListener("click", () => {
  const newOwner = document.getElementById("newOwner").value;
  if (!newOwner) {
    document.getElementById("reassignError").textContent = "请选择新负责人";
    document.getElementById("reassignError").style.display = "block";
    return;
  }
  const oldOwner = customerDetail.owner;
  customerDetail.owner = newOwner;
  followUps.push({
    id: `f${nextFollowUpId++}`,
    customerId: customer.id,
    content: `客户从 ${oldOwner} 转交给 ${newOwner}`,
    method: "其他",
    createdBy: oldOwner,
    createdAt: new Date().toISOString(),
  });
  reassignModal.style.display = "none";
  renderTimeline();
  populateReassignOptions();
  showToast("客户已转交");
});

renderDetail();
