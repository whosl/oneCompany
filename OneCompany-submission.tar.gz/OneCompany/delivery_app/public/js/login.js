import { authenticate, getSession } from "./auth.js";

const session = getSession();
if (session) {
  const redirects = { sales: "/customers.html", admin: "/admin.html", manager: "/dashboard.html" };
  window.location.href = redirects[session.role] || "/customers.html";
}

const form = document.getElementById("loginForm");
const errorMsg = document.getElementById("errorMsg");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;

  if (!username || !password) {
    errorMsg.textContent = "请输入用户名和密码";
    errorMsg.style.display = "block";
    return;
  }

  const result = authenticate(username, password);
  if (result.success) {
    errorMsg.style.display = "none";
    window.location.href = result.redirectTo;
  } else {
    errorMsg.textContent = result.error;
    errorMsg.style.display = "block";
  }
});
