const SESSION_KEY = "crm_session";

const users = [
  { username: "sales1", role: "sales", displayName: "张销售" },
  { username: "sales2", role: "sales", displayName: "李销售" },
  { username: "admin1", role: "admin", displayName: "管理员" },
  { username: "manager1", role: "manager", displayName: "王经理" },
];

const passwords = {
  sales1: "123456",
  sales2: "123456",
  admin1: "admin123",
  manager1: "123456",
};

const roleRedirects = {
  sales: "/customers.html",
  admin: "/admin.html",
  manager: "/dashboard.html",
};

export function authenticate(username, password) {
  const user = users.find((u) => u.username === username);
  if (!user || passwords[username] !== password) {
    return { success: false, error: "用户名或密码错误" };
  }
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return {
    success: true,
    user,
    redirectTo: roleRedirects[user.role] || "/",
  };
}

export function getSession() {
  const raw = sessionStorage.getItem(SESSION_KEY);
  return raw ? JSON.parse(raw) : null;
}

export function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  window.location.href = "/login.html";
}

export function requireAuth() {
  const session = getSession();
  if (!session) {
    window.location.href = "/login.html";
    return null;
  }
  return session;
}
