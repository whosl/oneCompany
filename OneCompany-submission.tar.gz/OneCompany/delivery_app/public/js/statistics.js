import { requireAuth, logout } from "./auth.js";
import { customers, canAccessCustomer } from "./data.js";

const session = requireAuth();
if (!session) throw new Error("redirected");

const visibleCustomers = customers.filter((c) => canAccessCustomer(session, c));

document.getElementById("userName").textContent = session.displayName;
document.getElementById("logoutBtn").addEventListener("click", logout);

const members = [
  { username: "sales1", displayName: "张销售" },
  { username: "sales2", displayName: "李销售" },
];

function computeOverview(list, refDate) {
  const total = list.length;
  const high = list.filter((c) => c.intentionLevel === "高").length;
  const medium = list.filter((c) => c.intentionLevel === "中").length;
  const low = list.filter((c) => c.intentionLevel === "低").length;
  const rate = total > 0 ? high / total : 0;
  const ref = refDate ? new Date(refDate) : new Date();
  const monthStr = `${ref.getFullYear()}-${String(ref.getMonth() + 1).padStart(2, "0")}`;
  const newMonth = list.filter((c) => c.createdAt.startsWith(monthStr)).length;
  return { total, high, medium, low, rate, newMonth };
}

function computeDistribution(list) {
  const counts = { "高": 0, "中": 0, "低": 0 };
  for (const c of list) counts[c.intentionLevel]++;
  return [
    { level: "高", count: counts["高"], color: "#dc2626" },
    { level: "中", count: counts["中"], color: "#d97706" },
    { level: "低", count: counts["低"], color: "#16a34a" },
  ];
}

function computeRanking(list) {
  const map = {};
  for (const c of list) map[c.ownerUsername] = (map[c.ownerUsername] || 0) + 1;
  return members
    .map((m) => ({ ...m, count: map[m.username] || 0 }))
    .sort((a, b) => b.count - a.count);
}

function computeTrend(list, days) {
  const end = new Date();
  const start = new Date();
  start.setDate(end.getDate() - days + 1);
  const points = [];
  const d = new Date(start);
  while (d <= end) {
    const key = d.toISOString().slice(0, 10);
    points.push({ date: key, count: 0 });
    d.setDate(d.getDate() + 1);
  }
  for (const c of list) {
    const day = c.createdAt.slice(0, 10);
    const pt = points.find((p) => p.date === day);
    if (pt) pt.count++;
  }
  return points;
}

function filterByRange(list, range) {
  if (range === "all") return list;
  const days = range === "7d" ? 7 : range === "30d" ? 30 : 90;
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  const cutoffStr = cutoff.toISOString();
  return list.filter((c) => c.createdAt >= cutoffStr);
}

function renderCards(overview) {
  document.querySelector('[data-testid="total-count"]').textContent = overview.total;
  document.querySelector('[data-testid="high-count"]').textContent = overview.high;
  document.querySelector('[data-testid="medium-count"]').textContent = overview.medium;
  document.querySelector('[data-testid="low-count"]').textContent = overview.low;
  document.querySelector('[data-testid="conversion-rate"]').textContent = (overview.rate * 100).toFixed(1) + "%";
  document.querySelector('[data-testid="new-this-month"]').textContent = overview.newMonth;
}

function drawPie(canvas, dist) {
  const ctx = canvas.getContext("2d");
  const total = dist.reduce((s, d) => s + d.count, 0);
  const cx = canvas.width / 2;
  const cy = canvas.height / 2;
  const r = Math.min(cx, cy) - 20;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (total === 0) {
    ctx.fillStyle = "#e5e7eb";
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#999";
    ctx.font = "14px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("暂无数据", cx, cy + 5);
    return;
  }

  let startAngle = -Math.PI / 2;
  for (const d of dist) {
    const slice = (d.count / total) * Math.PI * 2;
    ctx.fillStyle = d.color;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, r, startAngle, startAngle + slice);
    ctx.closePath();
    ctx.fill();
    startAngle += slice;
  }

  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.45, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#333";
  ctx.font = "bold 20px sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(total.toString(), cx, cy);
}

function renderPieLegend(dist) {
  const el = document.getElementById("pieLegend");
  el.innerHTML = dist
    .map((d) => `<span class="legend-item"><span class="legend-dot" style="background:${d.color}"></span>${d.level}: ${d.count}</span>`)
    .join("");
}

function drawBar(canvas, ranking) {
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const maxCount = Math.max(...ranking.map((r) => r.count), 1);
  const barW = 60;
  const gap = 40;
  const chartH = canvas.height - 60;
  const startX = 60;

  ctx.strokeStyle = "#e5e7eb";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = 20 + (chartH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(startX, y);
    ctx.lineTo(canvas.width - 20, y);
    ctx.stroke();
    ctx.fillStyle = "#999";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(Math.round(maxCount - (maxCount / 4) * i).toString(), startX - 8, y + 4);
  }

  ranking.forEach((m, i) => {
    const x = startX + i * (barW + gap) + gap / 2;
    const barH = (m.count / maxCount) * chartH;
    const y = 20 + chartH - barH;

    ctx.fillStyle = "#1a73e8";
    ctx.fillRect(x, y, barW, barH);

    ctx.fillStyle = "#333";
    ctx.font = "bold 14px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(m.count.toString(), x + barW / 2, y - 8);

    ctx.fillStyle = "#333";
    ctx.font = "12px sans-serif";
    ctx.fillText(m.displayName, x + barW / 2, canvas.height - 8);

    ctx.fillStyle = "transparent";
    ctx.fillRect(x, y, barW, barH + 30);
  });

  canvas._rankingData = ranking;
  canvas._barLayout = ranking.map((m, i) => ({
    x: startX + i * (barW + gap) + gap / 2,
    w: barW,
    username: m.username,
  }));
}

function drawLine(canvas, trend) {
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const maxCount = Math.max(...trend.map((t) => t.count), 1);
  const padL = 50;
  const padR = 20;
  const padT = 20;
  const padB = 40;
  const chartW = canvas.width - padL - padR;
  const chartH = canvas.height - padT - padB;

  ctx.strokeStyle = "#e5e7eb";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = padT + (chartH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(padL, y);
    ctx.lineTo(canvas.width - padR, y);
    ctx.stroke();
    ctx.fillStyle = "#999";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(Math.round(maxCount - (maxCount / 4) * i).toString(), padL - 8, y + 4);
  }

  if (trend.length < 2) return;

  const stepX = chartW / (trend.length - 1);

  ctx.strokeStyle = "#1a73e8";
  ctx.lineWidth = 2;
  ctx.beginPath();
  trend.forEach((t, i) => {
    const x = padL + i * stepX;
    const y = padT + chartH - (t.count / maxCount) * chartH;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = "#1a73e8";
  trend.forEach((t, i) => {
    const x = padL + i * stepX;
    const y = padT + chartH - (t.count / maxCount) * chartH;
    ctx.beginPath();
    ctx.arc(x, y, 3, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.fillStyle = "#999";
  ctx.font = "10px sans-serif";
  ctx.textAlign = "center";
  const labelStep = Math.max(1, Math.floor(trend.length / 7));
  trend.forEach((t, i) => {
    if (i % labelStep === 0 || i === trend.length - 1) {
      const x = padL + i * stepX;
      ctx.fillText(t.date.slice(5), x, canvas.height - 8);
    }
  });
}

function render(range) {
  const filtered = filterByRange(visibleCustomers, range);
  const overview = computeOverview(filtered);
  const dist = computeDistribution(filtered);
  const ranking = computeRanking(filtered);
  const days = range === "7d" ? 7 : range === "30d" ? 30 : range === "90d" ? 90 : 365;
  const trend = computeTrend(filtered, days);

  renderCards(overview);
  drawPie(document.getElementById("pieChart"), dist);
  renderPieLegend(dist);
  drawBar(document.getElementById("barChart"), ranking);
  drawLine(document.getElementById("lineChart"), trend);
}

document.getElementById("barChart").addEventListener("click", (e) => {
  const canvas = e.target;
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;

  if (canvas._barLayout) {
    for (const bar of canvas._barLayout) {
      if (x >= bar.x && x <= bar.x + bar.w) {
        window.location.href = `/customers.html?owner=${bar.username}`;
        return;
      }
    }
  }
});

document.getElementById("timeRange").addEventListener("change", (e) => {
  render(e.target.value);
});

render("30d");
