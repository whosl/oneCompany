import { getSession } from "./auth.js";

const path = window.location.pathname;

if (path === "/" || path === "/index.html") {
  const session = getSession();
  if (session) {
    const redirects = { sales: "/customers.html", admin: "/admin.html", manager: "/statistics.html" };
    window.location.href = redirects[session.role] || "/login.html";
  } else {
    window.location.href = "/login.html";
  }
}
