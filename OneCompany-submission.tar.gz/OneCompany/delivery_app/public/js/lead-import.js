import { requireAuth, logout } from "./auth.js";
import { addCustomer, customers } from "./data.js";

const session = requireAuth();
if (!session) throw new Error("redirected");

document.getElementById("userName").textContent = session.displayName;
document.getElementById("logoutBtn").addEventListener("click", logout);

const LEADS_KEY = "crm_leads";

function loadLeads() {
  const raw = localStorage.getItem(LEADS_KEY);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    } catch {}
  }
  const defaults = [
    { company: "阿里巴巴", contactName: "张三", phone: "13800000001", email: "zhangsan@alibaba.com", intentionLevel: "高" },
    { company: "腾讯科技", contactName: "李四", phone: "13800000002", email: "lisi@tencent.com", intentionLevel: "高" },
    { company: "字节跳动", contactName: "王五", phone: "13800000003", email: "wangwu@bytedance.com", intentionLevel: "中" },
    { company: "美团", contactName: "赵六", phone: "13800000004", email: "zhaoliu@meituan.com", intentionLevel: "低" },
    { company: "京东集团", contactName: "张伟", phone: "13800000005", email: "zhangwei@jd.com", intentionLevel: "中" },
  ];
  localStorage.setItem(LEADS_KEY, JSON.stringify(defaults));
  return defaults;
}

function saveLeads(list) {
  localStorage.setItem(LEADS_KEY, JSON.stringify(list));
}

let leads = loadLeads();

let pendingLeads = [];
let pendingDuplicates = [];

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.style.display = "block";
  setTimeout(() => { toast.style.display = "none"; }, 3000);
}

// Tab switching
document.querySelectorAll(".import-tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".import-tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    const tabName = tab.dataset.tab;
    document.getElementById("manualPanel").style.display = tabName === "manual" ? "block" : "none";
    document.getElementById("batchPanel").style.display = tabName === "batch" ? "block" : "none";
  });
});

// Manual form
document.getElementById("manualForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const company = document.getElementById("m_company").value.trim();
  const contactName = document.getElementById("m_contactName").value.trim();
  const phone = document.getElementById("m_phone").value.trim();
  const email = document.getElementById("m_email").value.trim();
  const intentionLevel = document.getElementById("m_level").value;

  const errorEl = document.getElementById("manualError");
  const successEl = document.getElementById("manualSuccess");
  errorEl.style.display = "none";
  successEl.style.display = "none";

  if (!company) { errorEl.textContent = "公司名不能为空"; errorEl.style.display = "block"; return; }
  if (!contactName) { errorEl.textContent = "联系人不能为空"; errorEl.style.display = "block"; return; }

  const isDup = leads.some((l) => l.company === company && l.contactName === contactName);
  if (isDup) { errorEl.textContent = "线索重复，已存在相同公司名和联系人"; errorEl.style.display = "block"; return; }

  leads.push({ company, contactName, phone, email, intentionLevel });
  saveLeads(leads);
  successEl.textContent = "线索添加成功";
  successEl.style.display = "block";
  document.getElementById("manualForm").reset();
  setTimeout(() => { successEl.style.display = "none"; }, 3000);
});

// Download template
document.getElementById("downloadTemplateBtn").addEventListener("click", () => {
  const csvContent = "公司名,联系人,电话,邮箱,意向等级\n示例公司,张三,13800000001,zhangsan@example.com,高\n";
  const blob = new Blob(["\uFEFF" + csvContent], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "线索导入模板.xlsx";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast("模板下载成功");
});

// Upload CSV
document.getElementById("uploadBtn").addEventListener("click", () => {
  document.getElementById("fileInput").click();
});

document.getElementById("fileInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  document.getElementById("fileName").textContent = file.name;

  const reader = new FileReader();
  reader.onload = (ev) => {
    const text = ev.target.result;
    const parsed = parseCsv(text);
    previewImport(parsed);
  };
  reader.readAsText(file);
});

function parseCsv(text) {
  const lines = text.trim().split("\n");
  if (lines.length <= 1) return [];
  const result = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",").map((c) => c.trim());
    if (cols.length < 5) continue;
    const [company, contactName, phone, email, intentionLevel] = cols;
    if (!company || !contactName) continue;
    const validLevels = ["高", "中", "低"];
    result.push({
      company,
      contactName,
      phone,
      email,
      intentionLevel: validLevels.includes(intentionLevel) ? intentionLevel : "低",
    });
  }
  return result;
}

function previewImport(parsed) {
  pendingLeads = parsed;
  pendingDuplicates = [];

  const duplicates = [];
  const unique = [];
  for (const lead of parsed) {
    const isDup = leads.some((l) => l.company === lead.company && l.contactName === lead.contactName) ||
      duplicates.some((d) => d.company === lead.company && d.contactName === lead.contactName);
    if (isDup) {
      duplicates.push(lead);
    } else {
      unique.push(lead);
    }
  }
  pendingDuplicates = duplicates;

  const warningEl = document.getElementById("duplicateWarning");
  if (duplicates.length > 0) {
    warningEl.style.display = "block";
  } else {
    warningEl.style.display = "none";
  }

  const tbody = document.getElementById("previewBody");
  tbody.innerHTML = "";
  for (const lead of parsed) {
    const isDup = leads.some((l) => l.company === lead.company && l.contactName === lead.contactName);
    const tr = document.createElement("tr");
    if (isDup) tr.classList.add("duplicate-row");
    tr.innerHTML =
      "<td>" + lead.company + "</td>" +
      "<td>" + lead.contactName + "</td>" +
      "<td>" + lead.phone + "</td>" +
      "<td>" + lead.email + "</td>" +
      "<td>" + lead.intentionLevel + "</td>" +
      "<td>" + (isDup ? '<span class="level-badge level-高">重复</span>' : '<span class="level-badge level-低">新增</span>') + "</td>";
    tbody.appendChild(tr);
  }

  document.getElementById("previewSection").style.display = "block";
  document.getElementById("resultSection").style.display = "none";
}

document.getElementById("confirmImportBtn").addEventListener("click", () => {
  const dupAction = document.querySelector('input[name="dupAction"]:checked').value;
  let imported = 0;
  let skipped = 0;
  let overwritten = 0;

  for (const lead of pendingLeads) {
    const dupIndex = leads.findIndex((l) => l.company === lead.company && l.contactName === lead.contactName);
    if (dupIndex >= 0) {
      if (dupAction === "overwrite") {
        leads[dupIndex] = { ...lead };
        imported++;
        overwritten++;
      } else {
        skipped++;
      }
    } else {
      leads.push({ ...lead });
      imported++;
    }
  }

  saveLeads(leads);
  const summary = `共 ${pendingLeads.length} 条，导入 ${imported} 条，跳过 ${skipped} 条，覆盖 ${overwritten} 条`;
  document.getElementById("resultSummary").textContent = summary;
  document.getElementById("previewSection").style.display = "none";
  document.getElementById("resultSection").style.display = "block";
  showToast("导入完成");
});

document.getElementById("cancelImportBtn").addEventListener("click", () => {
  document.getElementById("previewSection").style.display = "none";
  document.getElementById("fileInput").value = "";
  document.getElementById("fileName").textContent = "";
});

document.getElementById("importMoreBtn").addEventListener("click", () => {
  document.getElementById("resultSection").style.display = "none";
  document.getElementById("fileInput").value = "";
  document.getElementById("fileName").textContent = "";
});
