import { requireAuth, logout } from "./auth.js";
import { customers, filterCustomers, sortCustomers, paginateCustomers, canAccessCustomer } from "./data.js";

const session = requireAuth();
if (!session) throw new Error("redirected");

document.getElementById("userName").textContent = session.displayName;
document.getElementById("logoutBtn").addEventListener("click", logout);

let currentFilters = {};
let currentSortField = "lastFollowUpAt";
let currentSortDir = "desc";
let currentPage = 1;
const pageSize = 5;

const urlParams = new URLSearchParams(window.location.search);
const ownerFilter = urlParams.get("owner");

function getFilteredCustomers() {
  let list = customers.filter((c) => canAccessCustomer(session, c));
  if (ownerFilter) {
    list = list.filter((c) => c.ownerUsername === ownerFilter);
  }
  return list;
}

function formatDate(iso) {
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  const h = String(d.getHours()).padStart(2, "0");
  const min = String(d.getMinutes()).padStart(2, "0");
  return `${y}-${m}-${day} ${h}:${min}`;
}

function render() {
  let filtered = filterCustomers(getFilteredCustomers(), currentFilters);
  let sorted = sortCustomers(filtered, currentSortField, currentSortDir);
  let paginated = paginateCustomers(sorted, currentPage, pageSize);

  const tbody = document.getElementById("customerTableBody");
  if (paginated.items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty-state">暂无匹配的客户数据</td></tr>';
  } else {
    tbody.innerHTML = paginated.items
      .map(
        (c) => `
      <tr class="clickable-row" data-testid="customer-row" data-id="${c.id}" onclick="window.location.href='/customer-detail.html?id=${c.id}'">
        <td>${c.name}</td>
        <td>${c.company}</td>
        <td>${c.intentionScore}</td>
        <td><span class="level-badge level-${c.intentionLevel}">${c.intentionLevel}</span></td>
        <td>${formatDate(c.lastFollowUpAt)}</td>
      </tr>
    `
      )
      .join("");
  }

  document.getElementById("pageInfo").textContent =
    `第 ${paginated.page} / ${paginated.totalPages} 页，共 ${paginated.total} 条`;
  document.getElementById("prevPage").disabled = currentPage <= 1;
  document.getElementById("nextPage").disabled = currentPage >= paginated.totalPages;

  const sortIcon = document.getElementById("sortIcon");
  if (currentSortField === "intentionScore") {
    sortIcon.textContent = currentSortDir === "desc" ? "↓" : "↑";
  } else {
    sortIcon.textContent = "⇅";
  }
}

// Search
document.getElementById("searchInput").addEventListener("input", (e) => {
  const keyword = e.target.value.trim();
  currentFilters = keyword ? { ...currentFilters, nameKeyword: keyword } : { ...currentFilters, nameKeyword: undefined };
  currentPage = 1;
  render();
});

// Filter tags
document.querySelectorAll(".filter-tag").forEach((btn) => {
  btn.addEventListener("click", () => {
    const level = btn.dataset.level;
    if (currentFilters.intentionLevel === level) {
      currentFilters = { ...currentFilters, intentionLevel: undefined };
      btn.classList.remove("active");
    } else {
      document.querySelectorAll(".filter-tag").forEach((b) => b.classList.remove("active"));
      currentFilters = { ...currentFilters, intentionLevel: level };
      btn.classList.add("active");
    }
    currentPage = 1;
    render();
  });
});

// Sort by intention score
document.querySelector('[data-sort="intentionScore"]').addEventListener("click", () => {
  if (currentSortField === "intentionScore") {
    currentSortDir = currentSortDir === "desc" ? "asc" : "desc";
  } else {
    currentSortField = "intentionScore";
    currentSortDir = "desc";
  }
  currentPage = 1;
  render();
});

// Pagination
document.getElementById("prevPage").addEventListener("click", () => {
  if (currentPage > 1) {
    currentPage--;
    render();
  }
});

document.getElementById("nextPage").addEventListener("click", () => {
  currentPage++;
  render();
});

render();
